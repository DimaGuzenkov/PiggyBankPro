package com.example.piggybankpro.data.local.entities;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "goal_deposit_cross_ref",
        primaryKeys = {"goal_id", "auto_deposit_id"},
        foreignKeys = {
                @ForeignKey(
                        entity = GoalEntity.class,
                        parentColumns = "id",
                        childColumns = "goal_id",
                        onDelete = ForeignKey.CASCADE
                ),
                @ForeignKey(
                        entity = AutoDepositEntity.class,
                        parentColumns = "id",
                        childColumns = "auto_deposit_id",
                        onDelete = ForeignKey.CASCADE
                )
        },
        indices = {
                @Index(value = {"goal_id"}),
                @Index(value = {"auto_deposit_id"}),
                @Index(value = {"goal_id", "auto_deposit_id"}, unique = true)
        }
)
public class GoalDepositCrossRefEntity {

    @ColumnInfo(name = "goal_id")
    @NonNull
    private String goalId;

    @ColumnInfo(name = "auto_deposit_id")
    @NonNull
    private String autoDepositId;

    @ColumnInfo(name = "amount")
    private Double amount; // Конкретная сумма для этой цели

    @ColumnInfo(name = "percentage")
    private Double percentage; // Процент от общей суммы автопополнения

    @ColumnInfo(name = "distribution_type", defaultValue = "1")
    private Integer distributionType = 1; // 1 - фиксированная сумма, 2 - процент

    @ColumnInfo(name = "created_at")
    private Long createdAt = System.currentTimeMillis();

    @ColumnInfo(name = "updated_at")
    private Long updatedAt = System.currentTimeMillis();

    // Конструкторы

    public GoalDepositCrossRefEntity() {
        goalId = "";
        autoDepositId = "";
    }

    @Ignore
    public GoalDepositCrossRefEntity(String goalId, String autoDepositId) {
        this.goalId = goalId;
        this.autoDepositId = autoDepositId;
    }

    // Геттеры и сеттеры
    public String getGoalId() {
        return goalId;
    }

    public void setGoalId(String goalId) {
        this.goalId = goalId;
        this.updatedAt = System.currentTimeMillis();
    }

    public String getAutoDepositId() {
        return autoDepositId;
    }

    public void setAutoDepositId(String autoDepositId) {
        this.autoDepositId = autoDepositId;
        this.updatedAt = System.currentTimeMillis();
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
        this.updatedAt = System.currentTimeMillis();
    }

    public Double getPercentage() {
        return percentage;
    }

    public void setPercentage(Double percentage) {
        this.percentage = percentage;
        this.updatedAt = System.currentTimeMillis();
    }

    public Integer getDistributionType() {
        return distributionType;
    }

    public void setDistributionType(Integer distributionType) {
        this.distributionType = distributionType;
        this.updatedAt = System.currentTimeMillis();
    }

    public Long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Long createdAt) {
        this.createdAt = createdAt;
    }

    public Long getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Long updatedAt) {
        this.updatedAt = updatedAt;
    }

    // Вспомогательные методы
    public Double calculateAmount(Double totalDepositAmount) {
        if (distributionType == 1) {
            return amount != null ? amount : 0.0;
        } else if (distributionType == 2 && percentage != null && totalDepositAmount != null) {
            return (percentage / 100.0) * totalDepositAmount;
        }
        return 0.0;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        GoalDepositCrossRefEntity that = (GoalDepositCrossRefEntity) o;

        if (!goalId.equals(that.goalId)) return false;
        return autoDepositId.equals(that.autoDepositId);
    }

    @Override
    public int hashCode() {
        int result = goalId.hashCode();
        result = 31 * result + autoDepositId.hashCode();
        return result;
    }
}