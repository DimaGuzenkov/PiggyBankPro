package com.example.piggybankpro.presentation.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.piggybankpro.R;
import com.example.piggybankpro.data.local.entities.GoalEntity;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class GoalAdapter extends RecyclerView.Adapter<GoalAdapter.GoalViewHolder> {

    public interface OnGoalClickListener {
        void onGoalClick(GoalEntity goal);
        void onGoalLongClick(GoalEntity goal, View view);
    }

    private List<GoalEntity> goals;
    private OnGoalClickListener listener;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault());

    public GoalAdapter(List<GoalEntity> goals, OnGoalClickListener listener) {
        this.goals = goals;
        this.listener = listener;
    }

    public void updateGoals(List<GoalEntity> newGoals) {
        this.goals = newGoals;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public GoalViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_goal, parent, false);
        return new GoalViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GoalViewHolder holder, int position) {
        GoalEntity goal = goals.get(position);
        holder.bind(goal);

        holder.cardView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onGoalClick(goal);
            }
        });

        holder.cardView.setOnLongClickListener(v -> {
            if (listener != null) {
                listener.onGoalLongClick(goal, v);
                return true;
            }
            return false;
        });
    }

    @Override
    public int getItemCount() {
        return goals != null ? goals.size() : 0;
    }

    class GoalViewHolder extends RecyclerView.ViewHolder {

        CardView cardView;
        TextView textViewTitle;
        TextView textViewTargetAmount;
        TextView textViewCurrentAmount;
        TextView textViewProgressPercentage;
        TextView textViewDaysLeft;
        ProgressBar progressBar;
        ImageView imageViewIcon;
        ImageView imageViewCompleted;

        public GoalViewHolder(@NonNull View itemView) {
            super(itemView);

            cardView = itemView.findViewById(R.id.card_view_goal);
            textViewTitle = itemView.findViewById(R.id.text_view_title);
            textViewTargetAmount = itemView.findViewById(R.id.text_view_target_amount);
            textViewCurrentAmount = itemView.findViewById(R.id.text_view_current_amount);
            textViewProgressPercentage = itemView.findViewById(R.id.text_view_progress_percentage);
            textViewDaysLeft = itemView.findViewById(R.id.text_view_days_left);
            progressBar = itemView.findViewById(R.id.progress_bar);
            imageViewIcon = itemView.findViewById(R.id.image_view_icon);
            imageViewCompleted = itemView.findViewById(R.id.image_view_completed);
        }

        public void bind(GoalEntity goal) {
            // Заголовок
            textViewTitle.setText(goal.getTitle());

            // Суммы
            if (goal.getTargetAmount() != null) {
                textViewTargetAmount.setText(formatCurrency(goal.getTargetAmount()));
                textViewTargetAmount.setVisibility(View.VISIBLE);
            } else {
                textViewTargetAmount.setVisibility(View.GONE);
            }

            textViewCurrentAmount.setText(formatCurrency(goal.getCurrentAmount()));

            // Прогресс
            Double progress = goal.getProgressPercentage();
            if (progress != null) {
                textViewProgressPercentage.setText(String.format(Locale.getDefault(), "%.1f%%", progress));
                progressBar.setProgress((int) Math.min(progress, 100));

                // Цвет прогресс-бара в зависимости от прогресса
                if (progress < 30) {
                    progressBar.setProgressTintList(android.content.res.ColorStateList.valueOf(
                            itemView.getContext().getResources().getColor(R.color.progress_low, null)
                    ));
                } else if (progress < 70) {
                    progressBar.setProgressTintList(android.content.res.ColorStateList.valueOf(
                            itemView.getContext().getResources().getColor(R.color.progress_medium, null)
                    ));
                } else {
                    progressBar.setProgressTintList(android.content.res.ColorStateList.valueOf(
                            itemView.getContext().getResources().getColor(R.color.progress_high, null)
                    ));
                }
            } else {
                textViewProgressPercentage.setText("0%");
                progressBar.setProgress(0);
            }

            // Дни до цели
            Long daysLeft = goal.getDaysRemaining();
            if (daysLeft != null) {
                textViewDaysLeft.setText(formatDays(daysLeft));
                textViewDaysLeft.setVisibility(View.VISIBLE);
            } else {
                textViewDaysLeft.setVisibility(View.GONE);
            }

            // Иконка
            if (goal.getColor() != null) {
                imageViewIcon.setColorFilter(goal.getColor());
            }

            // Статус завершения
            if (goal.getIsCompleted() != null && goal.getIsCompleted()) {
                imageViewCompleted.setVisibility(View.VISIBLE);
                cardView.setAlpha(0.8f);
            } else {
                imageViewCompleted.setVisibility(View.GONE);
                cardView.setAlpha(1.0f);
            }

            // Статус архивации
            if (goal.getIsArchived() != null && goal.getIsArchived()) {
                cardView.setCardBackgroundColor(
                        itemView.getContext().getResources().getColor(R.color.archived, null)
                );
            } else {
                cardView.setCardBackgroundColor(
                        itemView.getContext().getResources().getColor(R.color.surface, null)
                );
            }

            // Для директорий
            if (goal.getIsDirectory() != null && goal.getIsDirectory()) {
                imageViewIcon.setImageResource(R.drawable.ic_folder);
            } else {
                imageViewIcon.setImageResource(R.drawable.ic_goal);
            }
        }

        private String formatCurrency(double amount) {
            return String.format(Locale.getDefault(), "%.2f ₽", amount);
        }

        private String formatDays(long days) {
            if (days == 0) {
                return "Сегодня";
            } else if (days == 1) {
                return "1 день";
            } else if (days < 5) {
                return days + " дня";
            } else {
                return days + " дней";
            }
        }
    }
}