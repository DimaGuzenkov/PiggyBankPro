package com.example.piggybankpro.data.local.dao;


import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Embedded;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Relation;
import androidx.room.Transaction;
import androidx.room.Update;

import com.example.piggybankpro.data.local.entities.AutoDepositEntity;
import com.example.piggybankpro.data.local.entities.GoalDepositCrossRefEntity;

import java.util.List;

@Dao
public interface AutoDepositDao {

    // CRUD операции
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(AutoDepositEntity autoDeposit);

    @Update
    void update(AutoDepositEntity autoDeposit);

    @Delete
    void delete(AutoDepositEntity autoDeposit);

    @Query("DELETE FROM auto_deposits WHERE id = :depositId")
    void deleteById(String depositId);

    // Получение данных
    @Query("SELECT * FROM auto_deposits ORDER BY created_at DESC")
    LiveData<List<AutoDepositEntity>> getAllAutoDeposits();

    @Query("SELECT * FROM auto_deposits WHERE id = :depositId")
    LiveData<AutoDepositEntity> getAutoDepositById(String depositId);

    @Query("SELECT * FROM auto_deposits WHERE is_active = 1 ORDER BY next_execution_date ASC")
    LiveData<List<AutoDepositEntity>> getActiveAutoDeposits();

    @Query("SELECT * FROM auto_deposits WHERE is_active = 1 AND next_execution_date <= :currentTime")
    List<AutoDepositEntity> getDueAutoDeposits(long currentTime);

    // Обновление статусов
    @Query("UPDATE auto_deposits SET is_active = :isActive WHERE id = :depositId")
    void setActive(String depositId, boolean isActive);

    @Query("UPDATE auto_deposits SET next_execution_date = :nextExecution WHERE id = :depositId")
    void updateNextExecution(String depositId, long nextExecution);

    @Query("UPDATE auto_deposits SET last_execution_date = :lastExecution WHERE id = :depositId")
    void updateLastExecution(String depositId, long lastExecution);

    // Работа с целями (через связующую таблицу)
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertCrossRef(GoalDepositCrossRefEntity crossRef);

    @Delete
    void deleteCrossRef(GoalDepositCrossRefEntity crossRef);

    @Query("DELETE FROM goal_deposit_cross_ref WHERE auto_deposit_id = :depositId")
    void deleteAllCrossRefs(String depositId);

    @Query("SELECT * FROM goal_deposit_cross_ref WHERE auto_deposit_id = :depositId")
    LiveData<List<GoalDepositCrossRefEntity>> getCrossRefsByDepositId(String depositId);

    @Query("SELECT * FROM goal_deposit_cross_ref WHERE goal_id = :goalId")
    LiveData<List<GoalDepositCrossRefEntity>> getCrossRefsByGoalId(String goalId);

    // Получение автопополнений с целями
    @Transaction
    @Query("SELECT * FROM auto_deposits WHERE id = :depositId")
    AutoDepositWithGoals getAutoDepositWithGoals(String depositId);

    // Статистика
    @Query("SELECT COUNT(*) FROM auto_deposits WHERE is_active = 1")
    LiveData<Integer> getActiveDepositsCount();

    @Query("SELECT SUM(amount) FROM auto_deposits WHERE is_active = 1")
    LiveData<Double> getTotalMonthlyDeposit();

    // Класс для представления автопополнения с целями

    // Измененный класс AutoDepositWithGoals
    public static class AutoDepositWithGoals {
        @Embedded
        public AutoDepositEntity autoDeposit;

        @Relation(
                parentColumn = "id",
                entityColumn = "auto_deposit_id",
                entity = GoalDepositCrossRefEntity.class
        )
        public List<GoalDepositCrossRefEntity> goalCrossRefs;
    }
}
