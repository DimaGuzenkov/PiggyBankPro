package com.example.piggybankpro.presentation.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.piggybankpro.R;
import com.example.piggybankpro.data.local.entities.GoalEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class GoalSelectionAdapter extends RecyclerView.Adapter<GoalSelectionAdapter.GoalSelectionViewHolder> {

    private List<GoalEntity> allGoals;
    private List<GoalEntity> selectedGoals;

    public GoalSelectionAdapter(List<GoalEntity> allGoals, List<GoalEntity> selectedGoals) {
        this.allGoals = allGoals != null ? allGoals : new ArrayList<>();
        this.selectedGoals = selectedGoals != null ? selectedGoals : new ArrayList<>();
    }

    public void updateGoals(List<GoalEntity> newGoals) {
        this.allGoals = newGoals != null ? newGoals : new ArrayList<>();
        notifyDataSetChanged();
    }

    public List<GoalEntity> getSelectedGoals() {
        return selectedGoals;
    }

    @NonNull
    @Override
    public GoalSelectionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_goal_selection, parent, false);
        return new GoalSelectionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GoalSelectionViewHolder holder, int position) {
        GoalEntity goal = allGoals.get(position);
        holder.bind(goal);

        // Проверяем, выбрана ли цель
        boolean isSelected = isGoalSelected(goal);
        holder.checkBox.setChecked(isSelected);

        // Слушатель для CheckBox
        holder.checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                if (!isGoalSelected(goal)) {
                    selectedGoals.add(goal);
                }
            } else {
                selectedGoals.remove(goal);
            }
        });

        // Слушатель для всего элемента
        holder.itemView.setOnClickListener(v -> {
            holder.checkBox.setChecked(!holder.checkBox.isChecked());
        });
    }

    private boolean isGoalSelected(GoalEntity goal) {
        for (GoalEntity selected : selectedGoals) {
            if (selected.getId().equals(goal.getId())) {
                return true;
            }
        }
        return false;
    }

    @Override
    public int getItemCount() {
        return allGoals.size();
    }

    class GoalSelectionViewHolder extends RecyclerView.ViewHolder {

        CheckBox checkBox;
        TextView textViewTitle;
        TextView textViewAmount;

        public GoalSelectionViewHolder(@NonNull View itemView) {
            super(itemView);

            checkBox = itemView.findViewById(R.id.check_box);
            textViewTitle = itemView.findViewById(R.id.text_view_title);
            textViewAmount = itemView.findViewById(R.id.text_view_amount);
        }

        public void bind(GoalEntity goal) {
            textViewTitle.setText(goal.getTitle());
            textViewAmount.setText(String.format(Locale.getDefault(), "%.2f ₽", goal.getCurrentAmount()));

            // Для архивных или завершенных целей делаем недоступными
            if ((goal.getIsArchived() != null && goal.getIsArchived()) ||
                    (goal.getIsCompleted() != null && goal.getIsCompleted())) {
                checkBox.setEnabled(false);
                itemView.setAlpha(0.5f);
            } else {
                checkBox.setEnabled(true);
                itemView.setAlpha(1.0f);
            }
        }
    }
}