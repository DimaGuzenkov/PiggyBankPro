package com.example.piggybankpro.data.local.entities;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Ignore;
import androidx.room.Index;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import com.example.piggybankpro.data.local.converters.DateConverter;

import java.util.Date;
import java.util.UUID;

@Entity(
        tableName = "goals",
        foreignKeys = @ForeignKey(
                entity = GoalEntity.class,
                parentColumns = "id",
                childColumns = "parent_id",
                onDelete = ForeignKey.CASCADE,
                onUpdate = ForeignKey.CASCADE
        ),
        indices = {
                @Index(value = {"parent_id"}),
                @Index(value = {"priority"}),
                @Index(value = {"target_date"}),
                @Index(value = {"is_directory"})
        }
)
@TypeConverters(DateConverter.class)
public class GoalEntity {

    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "id")
    private String id = UUID.randomUUID().toString();

    @ColumnInfo(name = "title", defaultValue = "Новая цель")
    private String title;

    @ColumnInfo(name = "description")
    private String description;

    @ColumnInfo(name = "target_amount")
    private Double targetAmount;

    @ColumnInfo(name = "current_amount", defaultValue = "0.0")
    private Double currentAmount = 0.0;

    @ColumnInfo(name = "currency", defaultValue = "RUB")
    private String currency = "RUB";

    @ColumnInfo(name = "target_date")
    private Date targetDate;

    @ColumnInfo(name = "created_at")
    private Date createdAt = new Date();

    @ColumnInfo(name = "updated_at")
    private Date updatedAt = new Date();

    @ColumnInfo(name = "color")
    private Integer color;

    @ColumnInfo(name = "icon_name")
    private String iconName;

    @ColumnInfo(name = "image_url")
    private String imageUrl;

    @ColumnInfo(name = "priority", defaultValue = "1")
    private Integer priority = 1;

    @ColumnInfo(name = "goal_url")
    private String goalUrl;

    @ColumnInfo(name = "parent_id")
    private String parentId;

    @ColumnInfo(name = "is_directory", defaultValue = "0")
    private Boolean isDirectory = false;

    @ColumnInfo(name = "order_position", defaultValue = "0")
    private Integer orderPosition = 0;

    @ColumnInfo(name = "is_archived", defaultValue = "0")
    private Boolean isArchived = false;

    @ColumnInfo(name = "is_completed", defaultValue = "0")
    private Boolean isCompleted = false;

    @ColumnInfo(name = "completed_date")
    private Date completedDate;

    @ColumnInfo(name = "auto_deposit_enabled", defaultValue = "0")
    private Boolean autoDepositEnabled = false;

    @ColumnInfo(name = "notification_enabled", defaultValue = "1")
    private Boolean notificationEnabled = true;

    @ColumnInfo(name = "notes")
    private String notes;

    // Конструкторы
    public GoalEntity() {
        // Пустой конструктор для Room
    }

    @Ignore
    public GoalEntity(String title) {
        this.title = title;
        this.createdAt = new Date();
        this.updatedAt = new Date();
    }

    @Ignore
    public GoalEntity(String title, Double targetAmount, Date targetDate) {
        this.title = title;
        this.targetAmount = targetAmount;
        this.targetDate = targetDate;
        this.createdAt = new Date();
        this.updatedAt = new Date();
    }

    // Геттеры и сеттеры
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
        this.updatedAt = new Date();
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
        this.updatedAt = new Date();
    }

    public Double getTargetAmount() {
        return targetAmount;
    }

    public void setTargetAmount(Double targetAmount) {
        this.targetAmount = targetAmount;
        this.updatedAt = new Date();
    }

    public Double getCurrentAmount() {
        return currentAmount;
    }

    public void setCurrentAmount(Double currentAmount) {
        this.currentAmount = currentAmount;
        this.updatedAt = new Date();

        // Проверка на завершение цели
        if (targetAmount != null && currentAmount >= targetAmount) {
            this.isCompleted = true;
            this.completedDate = new Date();
        } else if (this.isCompleted) {
            this.isCompleted = false;
            this.completedDate = null;
        }
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
        this.updatedAt = new Date();
    }

    public Date getTargetDate() {
        return targetDate;
    }

    public void setTargetDate(Date targetDate) {
        this.targetDate = targetDate;
        this.updatedAt = new Date();
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Integer getColor() {
        return color;
    }

    public void setColor(Integer color) {
        this.color = color;
        this.updatedAt = new Date();
    }

    public String getIconName() {
        return iconName;
    }

    public void setIconName(String iconName) {
        this.iconName = iconName;
        this.updatedAt = new Date();
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
        this.updatedAt = new Date();
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
        this.updatedAt = new Date();
    }

    public String getGoalUrl() {
        return goalUrl;
    }

    public void setGoalUrl(String goalUrl) {
        this.goalUrl = goalUrl;
        this.updatedAt = new Date();
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
        this.updatedAt = new Date();
    }

    public Boolean getIsDirectory() {
        return isDirectory;
    }

    public void setIsDirectory(Boolean directory) {
        isDirectory = directory;
        this.updatedAt = new Date();
    }

    public Integer getOrderPosition() {
        return orderPosition;
    }

    public void setOrderPosition(Integer orderPosition) {
        this.orderPosition = orderPosition;
        this.updatedAt = new Date();
    }

    public Boolean getIsArchived() {
        return isArchived;
    }

    public void setIsArchived(Boolean archived) {
        isArchived = archived;
        this.updatedAt = new Date();
    }

    public Boolean getIsCompleted() {
        return isCompleted;
    }

    public void setIsCompleted(Boolean completed) {
        isCompleted = completed;
        this.updatedAt = new Date();
        if (completed) {
            this.completedDate = new Date();
        } else {
            this.completedDate = null;
        }
    }

    public Date getCompletedDate() {
        return completedDate;
    }

    public void setCompletedDate(Date completedDate) {
        this.completedDate = completedDate;
        this.updatedAt = new Date();
    }

    public Boolean getAutoDepositEnabled() {
        return autoDepositEnabled;
    }

    public void setAutoDepositEnabled(Boolean autoDepositEnabled) {
        this.autoDepositEnabled = autoDepositEnabled;
        this.updatedAt = new Date();
    }

    public Boolean getNotificationEnabled() {
        return notificationEnabled;
    }

    public void setNotificationEnabled(Boolean notificationEnabled) {
        this.notificationEnabled = notificationEnabled;
        this.updatedAt = new Date();
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
        this.updatedAt = new Date();
    }

    // Вспомогательные методы
    public Double getProgressPercentage() {
        if (targetAmount == null || targetAmount == 0) {
            return 0.0;
        }
        return (currentAmount / targetAmount) * 100;
    }

    public Long getDaysRemaining() {
        if (targetDate == null) {
            return null;
        }
        long diff = targetDate.getTime() - new Date().getTime();
        return diff / (1000 * 60 * 60 * 24);
    }

    public Double getAmountNeeded() {
        if (targetAmount == null) {
            return null;
        }
        return Math.max(0, targetAmount - currentAmount);
    }

    public void deposit(Double amount) {
        if (amount != null && amount > 0) {
            this.currentAmount += amount;
            this.updatedAt = new Date();
        }
    }

    public void withdraw(Double amount) {
        if (amount != null && amount > 0 && this.currentAmount >= amount) {
            this.currentAmount -= amount;
            this.updatedAt = new Date();
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GoalEntity that = (GoalEntity) o;
        return id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }
}