package com.example.piggybankpro.data.local.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Embedded;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Relation;
import androidx.room.Transaction;
import androidx.room.Update;

import com.example.piggybankpro.data.local.entities.GoalEntity;

import java.util.List;

@Dao
public interface GoalDao {

    // CRUD операции
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(GoalEntity goal);

    @Update
    void update(GoalEntity goal);

    @Delete
    void delete(GoalEntity goal);

    @Query("DELETE FROM goals WHERE id = :goalId")
    void deleteById(String goalId);

    // Получение данных
    @Query("SELECT * FROM goals ORDER BY priority DESC, created_at DESC")
    LiveData<List<GoalEntity>> getAllGoals();

    @Query("SELECT * FROM goals WHERE id = :goalId")
    LiveData<GoalEntity> getGoalById(String goalId);

    @Query("SELECT * FROM goals WHERE parent_id IS NULL ORDER BY priority DESC, created_at DESC")
    LiveData<List<GoalEntity>> getRootGoals();

    @Query("SELECT * FROM goals WHERE parent_id = :parentId ORDER BY priority DESC, created_at DESC")
    LiveData<List<GoalEntity>> getSubGoals(String parentId);

    @Query("SELECT * FROM goals WHERE is_directory = 1 ORDER BY priority DESC, created_at DESC")
    LiveData<List<GoalEntity>> getDirectoryGoals();

    // Работа с суммами
    @Query("UPDATE goals SET current_amount = current_amount + :amount WHERE id = :goalId")
    void updateCurrentAmount(String goalId, Double amount);

    @Query("UPDATE goals SET current_amount = :newAmount WHERE id = :goalId")
    void setCurrentAmount(String goalId, Double newAmount);

    @Query("UPDATE goals SET current_amount = 0 WHERE id = :goalId")
    void resetCurrentAmount(String goalId);

    // Фильтрация
    @Query("SELECT * FROM goals WHERE is_completed = 1 ORDER BY completed_date DESC")
    LiveData<List<GoalEntity>> getCompletedGoals();

    @Query("SELECT * FROM goals WHERE is_completed = 0 ORDER BY priority DESC, created_at DESC")
    LiveData<List<GoalEntity>> getActiveGoals();

    @Query("SELECT * FROM goals WHERE is_archived = 1 ORDER BY created_at DESC")
    LiveData<List<GoalEntity>> getArchivedGoals();

    @Query("SELECT * FROM goals WHERE target_amount IS NOT NULL AND current_amount >= target_amount")
    LiveData<List<GoalEntity>> getReachedGoals();

    // Поиск
    @Query("SELECT * FROM goals WHERE title LIKE '%' || :query || '%' OR description LIKE '%' || :query || '%'")
    LiveData<List<GoalEntity>> searchGoals(String query);

    // Статистика
    @Query("SELECT COUNT(*) FROM goals")
    LiveData<Integer> getGoalsCount();

    @Query("SELECT COUNT(*) FROM goals WHERE is_completed = 1")
    LiveData<Integer> getCompletedGoalsCount();

    @Query("SELECT SUM(current_amount) FROM goals")
    LiveData<Double> getTotalSavedAmount();

    @Query("SELECT SUM(target_amount) FROM goals WHERE target_amount IS NOT NULL")
    LiveData<Double> getTotalTargetAmount();

    // Иерархические операции
    @Transaction
    @Query("SELECT * FROM goals WHERE id = :goalId")
    GoalEntityWithChildren getGoalWithChildren(String goalId);

    @Query("UPDATE goals SET parent_id = :newParentId WHERE id = :goalId")
    void updateParent(String goalId, String newParentId);

    @Query("UPDATE goals SET parent_id = NULL WHERE parent_id = :parentId")
    void detachFromParent(String parentId);

    // Для автопополнения
    @Query("SELECT * FROM goals WHERE auto_deposit_enabled = 1")
    LiveData<List<GoalEntity>> getGoalsWithAutoDeposit();

    // Массовые операции
    @Query("DELETE FROM goals WHERE is_archived = 1")
    void deleteArchivedGoals();

    @Query("UPDATE goals SET is_archived = :archived WHERE id = :goalId")
    void setArchived(String goalId, boolean archived);

    @Query("UPDATE goals SET is_completed = :completed WHERE id = :goalId")
    void setCompleted(String goalId, boolean completed);

    // Класс для представления цели с детьми
    public static class GoalEntityWithChildren {
        @Embedded
        public GoalEntity goal;

        @Relation(
                parentColumn = "id",
                entityColumn = "parent_id"
        )
        public List<GoalEntity> children;
    }
}
