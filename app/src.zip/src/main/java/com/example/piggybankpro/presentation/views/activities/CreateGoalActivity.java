package com.example.piggybankpro.presentation.views.activities;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.piggybankpro.R;
import com.example.piggybankpro.data.local.entities.GoalEntity;
import com.example.piggybankpro.presentation.viewmodels.GoalViewModel;
import com.github.dhaval2404.colorpicker.ColorPickerDialog;
import com.github.dhaval2404.colorpicker.listener.ColorListener;
import com.github.dhaval2404.colorpicker.model.ColorShape;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

public class CreateGoalActivity extends AppCompatActivity {

    private EditText editTextTitle;
    private EditText editTextDescription;
    private EditText editTextTargetAmount;
    private EditText editTextCurrentAmount;
    private EditText editTextGoalUrl;
    private Spinner spinnerPriority;
    private Button buttonDatePicker;
    private Button buttonColorPicker;
    private Button buttonSave;
    private Button buttonAutoFill;
    private ImageView imageViewColorPreview;

    private GoalViewModel goalViewModel;
    private Calendar targetDateCalendar;
    private int selectedColor = Color.parseColor("#4CAF50");
    private String editingGoalId = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_goal);

        // Инициализация Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Новая цель");

        // Инициализация ViewModel
        goalViewModel = new androidx.lifecycle.ViewModelProvider(this).get(GoalViewModel.class);

        // Получение ID цели для редактирования (если есть)
        editingGoalId = getIntent().getStringExtra("goal_id");

        // Инициализация представлений
        initViews();

        // Настройка спиннера приоритета
        setupPrioritySpinner();

        // Настройка слушателей
        setupListeners();

        // Если редактируем существующую цель, загружаем данные
        if (editingGoalId != null) {
            loadGoalData();
        }

        // Наблюдение за ошибками
        observeViewModel();
    }

    private void initViews() {
        editTextTitle = findViewById(R.id.edit_text_title);
        editTextDescription = findViewById(R.id.edit_text_description);
        editTextTargetAmount = findViewById(R.id.edit_text_target_amount);
        editTextCurrentAmount = findViewById(R.id.edit_text_current_amount);
        editTextGoalUrl = findViewById(R.id.edit_text_goal_url);
        spinnerPriority = findViewById(R.id.spinner_priority);
        buttonDatePicker = findViewById(R.id.button_date_picker);
        buttonColorPicker = findViewById(R.id.button_color_picker);
        buttonSave = findViewById(R.id.button_save);
        buttonAutoFill = findViewById(R.id.button_auto_fill);
        imageViewColorPreview = findViewById(R.id.image_view_color_preview);

        targetDateCalendar = Calendar.getInstance();
        targetDateCalendar.add(Calendar.MONTH, 1); // По умолчанию +1 месяц

        updateDateButtonText();
        updateColorPreview();
    }

    private void setupPrioritySpinner() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.priority_levels,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPriority.setAdapter(adapter);
        spinnerPriority.setSelection(2); // Средний приоритет по умолчанию
    }

    private void setupListeners() {
        buttonDatePicker.setOnClickListener(v -> showDatePickerDialog());
        buttonColorPicker.setOnClickListener(v -> showColorPickerDialog());
        buttonSave.setOnClickListener(v -> saveGoal());
        buttonAutoFill.setOnClickListener(v -> autoFillFromUrl());

        // Настройка TextWatcher для форматирования суммы
        editTextTargetAmount.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(android.text.Editable s) {
                if (!s.toString().isEmpty()) {
                    try {
                        double value = Double.parseDouble(s.toString());
                        editTextTargetAmount.removeTextChangedListener(this);
                        editTextTargetAmount.setText(String.format(Locale.getDefault(), "%.2f", value));
                        editTextTargetAmount.setSelection(editTextTargetAmount.getText().length());
                        editTextTargetAmount.addTextChangedListener(this);
                    } catch (NumberFormatException e) {
                        // Игнорируем
                    }
                }
            }
        });

        editTextCurrentAmount.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(android.text.Editable s) {
                if (!s.toString().isEmpty()) {
                    try {
                        double value = Double.parseDouble(s.toString());
                        editTextCurrentAmount.removeTextChangedListener(this);
                        editTextCurrentAmount.setText(String.format(Locale.getDefault(), "%.2f", value));
                        editTextCurrentAmount.setSelection(editTextCurrentAmount.getText().length());
                        editTextCurrentAmount.addTextChangedListener(this);
                    } catch (NumberFormatException e) {
                        // Игнорируем
                    }
                }
            }
        });
    }

    private void showDatePickerDialog() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    targetDateCalendar.set(Calendar.YEAR, year);
                    targetDateCalendar.set(Calendar.MONTH, month);
                    targetDateCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    updateDateButtonText();
                },
                targetDateCalendar.get(Calendar.YEAR),
                targetDateCalendar.get(Calendar.MONTH),
                targetDateCalendar.get(Calendar.DAY_OF_MONTH)
        );

        // Устанавливаем минимальную дату - сегодня
        datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
        datePickerDialog.show();
    }

    private void showColorPickerDialog() {
        new ColorPickerDialog.Builder(this)
                .setTitle("Выберите цвет")
                .setColorShape(ColorShape.SQAURE)
                .setDefaultColor(selectedColor)
                .setColorListener(new ColorListener() {
                    @Override
                    public void onColorSelected(int color, String colorHex) {
                        selectedColor = color;
                        updateColorPreview();
                    }
                })
                .show();
    }

    private void updateDateButtonText() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault());
        buttonDatePicker.setText("Дата: " + sdf.format(targetDateCalendar.getTime()));
    }

    private void updateColorPreview() {
        imageViewColorPreview.setBackgroundColor(selectedColor);
    }

    private void saveGoal() {
        // Валидация
        if (TextUtils.isEmpty(editTextTitle.getText().toString().trim())) {
            editTextTitle.setError("Введите название цели");
            editTextTitle.requestFocus();
            return;
        }

        try {
            GoalEntity goal = new GoalEntity();

            // Если редактируем существующую цель
            if (editingGoalId != null) {
                goal.setId(editingGoalId);
            } else {
                goal.setId(UUID.randomUUID().toString());
            }

            // Основные данные
            goal.setTitle(editTextTitle.getText().toString().trim());
            goal.setDescription(editTextDescription.getText().toString().trim());

            // Суммы
            if (!TextUtils.isEmpty(editTextTargetAmount.getText().toString())) {
                goal.setTargetAmount(Double.parseDouble(editTextTargetAmount.getText().toString()));
            }

            if (!TextUtils.isEmpty(editTextCurrentAmount.getText().toString())) {
                goal.setCurrentAmount(Double.parseDouble(editTextCurrentAmount.getText().toString()));
            } else {
                goal.setCurrentAmount(0.0);
            }

            // Дата
            goal.setTargetDate(targetDateCalendar.getTime());

            // Цвет
            goal.setColor(selectedColor);

            // Приоритет
            goal.setPriority(spinnerPriority.getSelectedItemPosition() + 1); // 1-5

            // URL
            goal.setGoalUrl(editTextGoalUrl.getText().toString().trim());

            // Сохранение цели
            if (editingGoalId != null) {
                goalViewModel.updateGoal(goal);
                Toast.makeText(this, "Цель обновлена", Toast.LENGTH_SHORT).show();
            } else {
                goalViewModel.createGoal(goal);
                Toast.makeText(this, "Цель создана", Toast.LENGTH_SHORT).show();
            }

            // Возвращаемся на главный экран
            finish();

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Ошибка в формате суммы", Toast.LENGTH_SHORT).show();
        }
    }

    private void autoFillFromUrl() {
        String url = editTextGoalUrl.getText().toString().trim();

        if (TextUtils.isEmpty(url)) {
            Toast.makeText(this, "Введите URL для автозаполнения", Toast.LENGTH_SHORT).show();
            return;
        }

        // TODO: Реализовать логику автозаполнения из URL
        // Пока просто заглушка
        Toast.makeText(this, "Автозаполнение из URL...", Toast.LENGTH_SHORT).show();

        // Пример автозаполнения
        editTextTitle.setText("Авто-цель из сайта");
        editTextTargetAmount.setText("5000.00");
        editTextDescription.setText("Автоматически заполнено из сайта");

        // Устанавливаем цвет по умолчанию для автозаполненных целей
        selectedColor = Color.parseColor("#2196F3");
        updateColorPreview();
    }

    private void loadGoalData() {
        if (editingGoalId == null) return;

        goalViewModel.getGoalById(editingGoalId).observe(this, goal -> {
            if (goal != null) {
                // Заполняем поля данными из цели
                editTextTitle.setText(goal.getTitle());
                editTextDescription.setText(goal.getDescription());

                if (goal.getTargetAmount() != null) {
                    editTextTargetAmount.setText(String.format(Locale.getDefault(), "%.2f", goal.getTargetAmount()));
                }

                if (goal.getCurrentAmount() != null) {
                    editTextCurrentAmount.setText(String.format(Locale.getDefault(), "%.2f", goal.getCurrentAmount()));
                }

                if (goal.getGoalUrl() != null) {
                    editTextGoalUrl.setText(goal.getGoalUrl());
                }

                if (goal.getTargetDate() != null) {
                    targetDateCalendar.setTime(goal.getTargetDate());
                    updateDateButtonText();
                }

                if (goal.getColor() != null) {
                    selectedColor = goal.getColor();
                    updateColorPreview();
                }

                if (goal.getPriority() != null && goal.getPriority() > 0) {
                    spinnerPriority.setSelection(goal.getPriority() - 1);
                }

                getSupportActionBar().setTitle("Редактирование цели");
            }
        });
    }

    private void observeViewModel() {
        goalViewModel.getErrorMessage().observe(this, errorMessage -> {
            if (errorMessage != null) {
                Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show();
                goalViewModel.clearError();
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}