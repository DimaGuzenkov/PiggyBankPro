package com.example.piggybankpro.presentation.views.activities;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.piggybankpro.R;
import com.example.piggybankpro.data.local.entities.AutoDepositEntity;
import com.example.piggybankpro.data.local.entities.GoalDepositCrossRefEntity;
import com.example.piggybankpro.data.local.entities.GoalEntity;
import com.example.piggybankpro.presentation.adapters.AutoDepositAdapter;
import com.example.piggybankpro.presentation.adapters.GoalSelectionAdapter;
import com.example.piggybankpro.presentation.viewmodels.AutoDepositViewModel;
import com.example.piggybankpro.presentation.viewmodels.GoalViewModel;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class AutoDepositActivity extends AppCompatActivity {

    private RecyclerView recyclerViewAutoDeposits;
    private TextView textViewEmptyState;
    private Button buttonAddAutoDeposit;

    private AutoDepositViewModel autoDepositViewModel;
    private GoalViewModel goalViewModel;
    private AutoDepositAdapter autoDepositAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auto_deposit);

        // Настройка Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Автопополнение");

        // Инициализация ViewModels
        autoDepositViewModel = new ViewModelProvider(this).get(AutoDepositViewModel.class);
        goalViewModel = new ViewModelProvider(this).get(GoalViewModel.class);

        // Инициализация представлений
        initViews();

        // Настройка RecyclerView
        setupRecyclerView();

        // Наблюдение за данными
        observeViewModel();

        // Настройка кнопок
        setupButtons();
    }

    private void initViews() {
        recyclerViewAutoDeposits = findViewById(R.id.recycler_view_auto_deposits);
        textViewEmptyState = findViewById(R.id.text_view_empty_state);
        buttonAddAutoDeposit = findViewById(R.id.button_add_auto_deposit);
    }

    private void setupRecyclerView() {
        autoDepositAdapter = new AutoDepositAdapter(new ArrayList<>(), new AutoDepositAdapter.OnAutoDepositClickListener() {
            @Override
            public void onAutoDepositClick(AutoDepositEntity autoDeposit) {
                showEditAutoDepositDialog(autoDeposit);
            }

            @Override
            public void onAutoDepositLongClick(AutoDepositEntity autoDeposit, View view) {
                showContextMenu(autoDeposit, view);
            }

            @Override
            public void onToggleStatus(AutoDepositEntity autoDeposit, boolean isActive) {
                autoDepositViewModel.toggleAutoDepositStatus(autoDeposit.getId(), isActive);
            }
        });

        recyclerViewAutoDeposits.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewAutoDeposits.setAdapter(autoDepositAdapter);

        // Добавляем разделитель между элементами
        recyclerViewAutoDeposits.addItemDecoration(
                new androidx.recyclerview.widget.DividerItemDecoration(
                        this,
                        LinearLayoutManager.VERTICAL
                )
        );
    }

    private void observeViewModel() {
        // Подписка на список автопополнений
        autoDepositViewModel.getAllAutoDeposits().observe(this, autoDeposits -> {
            if (autoDeposits != null && !autoDeposits.isEmpty()) {
                autoDepositAdapter.updateAutoDeposits(autoDeposits);
                textViewEmptyState.setVisibility(View.GONE);
                recyclerViewAutoDeposits.setVisibility(View.VISIBLE);
            } else {
                textViewEmptyState.setVisibility(View.VISIBLE);
                recyclerViewAutoDeposits.setVisibility(View.GONE);
                textViewEmptyState.setText("У вас нет настроенных автопополнений\nНажмите + чтобы добавить");
            }
        });

        // Подписка на ошибки
        autoDepositViewModel.getErrorMessage().observe(this, errorMessage -> {
            if (errorMessage != null) {
                Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show();
                autoDepositViewModel.clearError();
            }
        });
    }

    private void setupButtons() {
        buttonAddAutoDeposit.setOnClickListener(v -> showCreateAutoDepositDialog());
    }

    private void showCreateAutoDepositDialog() {
        showAutoDepositDialog(null);
    }

    private void showEditAutoDepositDialog(AutoDepositEntity autoDeposit) {
        showAutoDepositDialog(autoDeposit);
    }

    private void showAutoDepositDialog(AutoDepositEntity existingAutoDeposit) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(existingAutoDeposit != null ? "Редактирование автопополнения" : "Новое автопополнение");

        // Создаем layout для диалога
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_auto_deposit, null);
        builder.setView(dialogView);

        // Инициализация элементов диалога
        EditText editTextName = dialogView.findViewById(R.id.edit_text_name);
        EditText editTextAmount = dialogView.findViewById(R.id.edit_text_amount);
        Spinner spinnerPeriod = dialogView.findViewById(R.id.spinner_period);
        Spinner spinnerDepositType = dialogView.findViewById(R.id.spinner_deposit_type);
        EditText editTextPercentage = dialogView.findViewById(R.id.edit_text_percentage);
        TextView textViewPercentageLabel = dialogView.findViewById(R.id.text_view_percentage_label);
        CheckBox checkBoxActive = dialogView.findViewById(R.id.check_box_active);
        Button buttonSelectGoals = dialogView.findViewById(R.id.button_select_goals);
        TextView textViewSelectedGoals = dialogView.findViewById(R.id.text_view_selected_goals);

        // Настройка спиннеров
        ArrayAdapter<CharSequence> periodAdapter = ArrayAdapter.createFromResource(
                this,
                R.array.period_types,
                android.R.layout.simple_spinner_item
        );
        periodAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPeriod.setAdapter(periodAdapter);

        ArrayAdapter<CharSequence> depositTypeAdapter = ArrayAdapter.createFromResource(
                this,
                R.array.deposit_types,
                android.R.layout.simple_spinner_item
        );
        depositTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDepositType.setAdapter(depositTypeAdapter);

        // Слушатель для типа пополнения
        spinnerDepositType.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                boolean isPercentage = position == 1; // 0 - фиксированная, 1 - процент
                editTextPercentage.setVisibility(isPercentage ? View.VISIBLE : View.GONE);
                textViewPercentageLabel.setVisibility(isPercentage ? View.VISIBLE : View.GONE);
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        // Заполняем данные, если редактируем существующее
        final List<GoalEntity> selectedGoals = new ArrayList<>();
        final List<GoalDepositCrossRefEntity> crossRefs = new ArrayList<>();

        if (existingAutoDeposit != null) {
            editTextName.setText(existingAutoDeposit.getName());
            editTextAmount.setText(String.valueOf(existingAutoDeposit.getAmount()));

            // Устанавливаем период
            int periodPosition = getPeriodPosition(existingAutoDeposit.getPeriodType());
            spinnerPeriod.setSelection(periodPosition);

            // Устанавливаем тип пополнения
            int depositTypePosition = existingAutoDeposit.getDepositType() == AutoDepositEntity.TYPE_PERCENTAGE ? 1 : 0;
            spinnerDepositType.setSelection(depositTypePosition);

            // Процент
            if (existingAutoDeposit.getPercentage() != null) {
                editTextPercentage.setText(String.valueOf(existingAutoDeposit.getPercentage()));
            }

            checkBoxActive.setChecked(existingAutoDeposit.getIsActive());

            // Загружаем выбранные цели
            autoDepositViewModel.getCrossRefsByDepositId(existingAutoDeposit.getId())
                    .observe(this, crossRefList -> {
                        if (crossRefList != null) {
                            crossRefs.clear();
                            crossRefs.addAll(crossRefList);

                            // Получаем информацию о целях
                            goalViewModel.getAllGoals().observe(this, allGoals -> {
                                if (allGoals != null) {
                                    selectedGoals.clear();
                                    for (GoalDepositCrossRefEntity crossRef : crossRefList) {
                                        for (GoalEntity goal : allGoals) {
                                            if (goal.getId().equals(crossRef.getGoalId())) {
                                                selectedGoals.add(goal);
                                                break;
                                            }
                                        }
                                    }
                                    updateSelectedGoalsText(textViewSelectedGoals, selectedGoals);
                                }
                            });
                        }
                    });
        }

        // Кнопка выбора целей
        buttonSelectGoals.setOnClickListener(v -> {
            showGoalSelectionDialog(selectedGoals, crossRefs, existingAutoDeposit);
        });

        builder.setPositiveButton("Сохранить", (dialog, which) -> {
            // Валидация и сохранение
            String name = editTextName.getText().toString().trim();
            String amountStr = editTextAmount.getText().toString().trim();
            String percentageStr = editTextPercentage.getText().toString().trim();

            if (name.isEmpty()) {
                Toast.makeText(this, "Введите название", Toast.LENGTH_SHORT).show();
                return;
            }

            if (amountStr.isEmpty()) {
                Toast.makeText(this, "Введите сумму", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double amount = Double.parseDouble(amountStr);
                if (amount <= 0) {
                    Toast.makeText(this, "Сумма должна быть больше нуля", Toast.LENGTH_SHORT).show();
                    return;
                }

                AutoDepositEntity autoDeposit = existingAutoDeposit != null ?
                        existingAutoDeposit : new AutoDepositEntity();

                autoDeposit.setName(name);
                autoDeposit.setAmount(amount);
                autoDeposit.setPeriodType(getPeriodTypeFromPosition(spinnerPeriod.getSelectedItemPosition()));
                autoDeposit.setDepositType(spinnerDepositType.getSelectedItemPosition() == 1 ?
                        AutoDepositEntity.TYPE_PERCENTAGE : AutoDepositEntity.TYPE_FIXED);
                autoDeposit.setIsActive(checkBoxActive.isChecked());

                if (spinnerDepositType.getSelectedItemPosition() == 1 && !percentageStr.isEmpty()) {
                    double percentage = Double.parseDouble(percentageStr);
                    if (percentage > 0 && percentage <= 100) {
                        autoDeposit.setPercentage(percentage);
                    }
                }

                // Сохраняем
                if (existingAutoDeposit != null) {
                    autoDepositViewModel.updateAutoDeposit(autoDeposit, crossRefs);
                    Toast.makeText(this, "Автопополнение обновлено", Toast.LENGTH_SHORT).show();
                } else {
                    autoDepositViewModel.createAutoDeposit(autoDeposit, crossRefs);
                    Toast.makeText(this, "Автопополнение создано", Toast.LENGTH_SHORT).show();
                }

            } catch (NumberFormatException e) {
                Toast.makeText(this, "Неверный формат числа", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Отмена", null);

        if (existingAutoDeposit != null) {
            builder.setNeutralButton("Удалить", (dialog, which) -> {
                new AlertDialog.Builder(this)
                        .setTitle("Удаление автопополнения")
                        .setMessage("Вы уверены, что хотите удалить это автопополнение?")
                        .setPositiveButton("Удалить", (dialog1, which1) -> {
                            autoDepositViewModel.deleteAutoDeposit(existingAutoDeposit);
                            Toast.makeText(this, "Автопополнение удалено", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("Отмена", null)
                        .show();
            });
        }

        builder.show();
    }

    private void showGoalSelectionDialog(List<GoalEntity> selectedGoals,
                                         List<GoalDepositCrossRefEntity> crossRefs,
                                         AutoDepositEntity autoDeposit) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Выбор целей для автопополнения");

        // Создаем RecyclerView для выбора целей
        RecyclerView recyclerView = new RecyclerView(this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        GoalSelectionAdapter adapter = new GoalSelectionAdapter(new ArrayList<>(), selectedGoals);
        recyclerView.setAdapter(adapter);

        // Загружаем цели
        goalViewModel.getAllGoals().observe(this, goals -> {
            if (goals != null) {
                adapter.updateGoals(goals);
            }
        });

        builder.setView(recyclerView);

        builder.setPositiveButton("Выбрать", (dialog, which) -> {
            // Обновляем crossRefs
            crossRefs.clear();
            for (GoalEntity goal : adapter.getSelectedGoals()) {
                GoalDepositCrossRefEntity crossRef = new GoalDepositCrossRefEntity(goal.getId(),
                        autoDeposit != null ? autoDeposit.getId() : "");
                crossRef.setDistributionType(1); // По умолчанию фиксированная сумма
                crossRefs.add(crossRef);
            }
        });

        builder.setNegativeButton("Отмена", null);

        builder.show();
    }

    private void showContextMenu(AutoDepositEntity autoDeposit, View view) {
        androidx.appcompat.widget.PopupMenu popupMenu = new androidx.appcompat.widget.PopupMenu(this, view);
        popupMenu.getMenuInflater().inflate(R.menu.menu_auto_deposit_context, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();

            if (id == R.id.action_edit) {
                showEditAutoDepositDialog(autoDeposit);
                return true;
            } else if (id == R.id.action_delete) {
                new AlertDialog.Builder(this)
                        .setTitle("Удаление автопополнения")
                        .setMessage("Вы уверены, что хотите удалить это автопополнение?")
                        .setPositiveButton("Удалить", (dialog, which) -> {
                            autoDepositViewModel.deleteAutoDeposit(autoDeposit);
                            Toast.makeText(this, "Автопополнение удалено", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("Отмена", null)
                        .show();
                return true;
            } else if (id == R.id.action_execute_now) {
                autoDepositViewModel.executeAutoDeposit(autoDeposit.getId());
                Toast.makeText(this, "Автопополнение выполнено", Toast.LENGTH_SHORT).show();
                return true;
            }

            return false;
        });

        popupMenu.show();
    }

    private int getPeriodPosition(int periodType) {
        switch (periodType) {
            case AutoDepositEntity.PERIOD_DAILY: return 0;
            case AutoDepositEntity.PERIOD_WEEKLY: return 1;
            case AutoDepositEntity.PERIOD_BIWEEKLY: return 2;
            case AutoDepositEntity.PERIOD_MONTHLY: return 3;
            case AutoDepositEntity.PERIOD_QUARTERLY: return 4;
            case AutoDepositEntity.PERIOD_YEARLY: return 5;
            default: return 3; // По умолчанию ежемесячно
        }
    }

    private int getPeriodTypeFromPosition(int position) {
        switch (position) {
            case 0: return AutoDepositEntity.PERIOD_DAILY;
            case 1: return AutoDepositEntity.PERIOD_WEEKLY;
            case 2: return AutoDepositEntity.PERIOD_BIWEEKLY;
            case 3: return AutoDepositEntity.PERIOD_MONTHLY;
            case 4: return AutoDepositEntity.PERIOD_QUARTERLY;
            case 5: return AutoDepositEntity.PERIOD_YEARLY;
            default: return AutoDepositEntity.PERIOD_MONTHLY;
        }
    }

    private void updateSelectedGoalsText(TextView textView, List<GoalEntity> selectedGoals) {
        if (selectedGoals.isEmpty()) {
            textView.setText("Не выбрано");
        } else if (selectedGoals.size() == 1) {
            textView.setText("1 цель выбрана");
        } else {
            textView.setText(selectedGoals.size() + " целей выбрано");
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_auto_deposit, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        } else if (id == R.id.action_execute_all) {
            autoDepositViewModel.executeDueAutoDeposits();
            Toast.makeText(this, "Все отложенные автопополнения выполнены", Toast.LENGTH_SHORT).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}