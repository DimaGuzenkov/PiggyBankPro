package com.example.piggybankpro.presentation.viewmodels;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.piggybankpro.data.local.entities.SettingsEntity;
import com.example.piggybankpro.data.repository.SettingsRepository;
import com.example.piggybankpro.data.repository.RepositoryFactory;

import java.util.Date;

public class SettingsViewModel extends AndroidViewModel {

    private SettingsRepository settingsRepository;
    private LiveData<SettingsEntity> settings;
    private MutableLiveData<Boolean> isLoading = new MutableLiveData<>(false);
    private MutableLiveData<String> successMessage = new MutableLiveData<>();
    private MutableLiveData<String> errorMessage = new MutableLiveData<>();

    public SettingsViewModel(@NonNull Application application) {
        super(application);
        settingsRepository = RepositoryFactory.getInstance(application).getSettingsRepository();
        settings = settingsRepository.getSettings();
    }

    // Получение настроек
    public LiveData<SettingsEntity> getSettings() {
        return settings;
    }

    // Обновление настроек
    public void updateSettings(SettingsEntity settings) {
        try {
            settingsRepository.updateSettings(settings);
            successMessage.setValue("Настройки сохранены");
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при сохранении настроек: " + e.getMessage());
            successMessage.setValue(null);
        }
    }

    // Обновление отдельных настроек
    public void updateNotificationsEnabled(boolean enabled) {
        try {
            settingsRepository.updateNotificationsEnabled(enabled);
            successMessage.setValue("Настройки уведомлений обновлены");
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при обновлении уведомлений: " + e.getMessage());
            successMessage.setValue(null);
        }
    }

    public void updateNotificationSoundEnabled(boolean enabled) {
        try {
            settingsRepository.updateNotificationSoundEnabled(enabled);
            successMessage.setValue("Настройки звука обновлены");
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при обновлении звука: " + e.getMessage());
            successMessage.setValue(null);
        }
    }

    public void updateVibrationEnabled(boolean enabled) {
        try {
            settingsRepository.updateVibrationEnabled(enabled);
            successMessage.setValue("Настройки вибрации обновлены");
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при обновлении вибрации: " + e.getMessage());
            successMessage.setValue(null);
        }
    }

    public void updateThemeMode(int themeMode) {
        try {
            settingsRepository.updateThemeMode(themeMode);
            successMessage.setValue("Тема обновлена");
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при обновлении темы: " + e.getMessage());
            successMessage.setValue(null);
        }
    }

    public void updateTextSize(int textSize) {
        try {
            if (textSize < 12 || textSize > 24) {
                errorMessage.setValue("Размер текста должен быть от 12 до 24");
                return;
            }
            settingsRepository.updateTextSize(textSize);
            successMessage.setValue("Размер текста обновлен");
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при обновлении размера текста: " + e.getMessage());
            successMessage.setValue(null);
        }
    }

    public void updateCurrency(String currency) {
        try {
            if (currency == null || currency.trim().isEmpty()) {
                errorMessage.setValue("Выберите валюту");
                return;
            }
            settingsRepository.updateCurrency(currency);
            successMessage.setValue("Валюта обновлена");
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при обновлении валюты: " + e.getMessage());
            successMessage.setValue(null);
        }
    }

    public void updateBiometricAuthEnabled(boolean enabled) {
        try {
            settingsRepository.updateBiometricAuthEnabled(enabled);
            successMessage.setValue("Настройки биометрии обновлены");
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при обновлении биометрии: " + e.getMessage());
            successMessage.setValue(null);
        }
    }

    public void updateAutoBackupEnabled(boolean enabled) {
        try {
            settingsRepository.updateAutoBackupEnabled(enabled);
            successMessage.setValue("Настройки резервного копирования обновлены");
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при обновлении резервного копирования: " + e.getMessage());
            successMessage.setValue(null);
        }
    }

    public void updateBackupFrequency(int frequency) {
        try {
            if (frequency < 1 || frequency > 30) {
                errorMessage.setValue("Частота резервного копирования должна быть от 1 до 30 дней");
                return;
            }
            settingsRepository.updateBackupFrequency(frequency);
            successMessage.setValue("Частота резервного копирования обновлена");
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при обновлении частоты копирования: " + e.getMessage());
            successMessage.setValue(null);
        }
    }

    public void updateLastBackupDate(Date backupDate) {
        try {
            settingsRepository.updateLastBackupDate(backupDate);
            successMessage.setValue("Дата резервного копирования обновлена");
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при обновлении даты копирования: " + e.getMessage());
            successMessage.setValue(null);
        }
    }

    // Работа с SharedPreferences
    public void saveString(String key, String value) {
        try {
            settingsRepository.saveString(key, value);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при сохранении: " + e.getMessage());
        }
    }

    public String getString(String key, String defaultValue) {
        return settingsRepository.getString(key, defaultValue);
    }

    public void saveBoolean(String key, boolean value) {
        try {
            settingsRepository.saveBoolean(key, value);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при сохранении: " + e.getMessage());
        }
    }

    public boolean getBoolean(String key, boolean defaultValue) {
        return settingsRepository.getBoolean(key, defaultValue);
    }

    // Состояние загрузки
    public LiveData<Boolean> getIsLoading() {
        return isLoading;
    }

    public void setLoading(boolean loading) {
        isLoading.setValue(loading);
    }

    // Сообщения
    public LiveData<String> getSuccessMessage() {
        return successMessage;
    }

    public LiveData<String> getErrorMessage() {
        return errorMessage;
    }

    public void clearMessages() {
        successMessage.setValue(null);
        errorMessage.setValue(null);
    }

    // Вспомогательные методы
    public String getThemeModeString(int themeMode) {
        switch (themeMode) {
            case SettingsEntity.THEME_LIGHT: return "Светлая";
            case SettingsEntity.THEME_DARK: return "Темная";
            case SettingsEntity.THEME_SYSTEM: return "Системная";
            default: return "Неизвестно";
        }
    }

    public boolean shouldBackupNow(SettingsEntity settings) {
        if (settings == null) return false;

        if (!settings.getAutoBackupEnabled() || settings.getLastBackupDate() == null) {
            return false;
        }

        long daysSinceLastBackup = (new Date().getTime() - settings.getLastBackupDate().getTime()) / (1000 * 60 * 60 * 24);
        return daysSinceLastBackup >= settings.getBackupFrequency();
    }
}