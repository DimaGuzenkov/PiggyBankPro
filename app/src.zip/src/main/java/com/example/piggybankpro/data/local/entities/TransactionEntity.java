package com.example.piggybankpro.data.local.entities;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Ignore;
import androidx.room.Index;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import com.example.piggybankpro.data.local.converters.DateConverter;

import java.util.Date;
import java.util.UUID;

@Entity(
        tableName = "transactions",
        foreignKeys = {
                @ForeignKey(
                        entity = GoalEntity.class,
                        parentColumns = "id",
                        childColumns = "goal_id",
                        onDelete = ForeignKey.CASCADE
                ),
                @ForeignKey(
                        entity = AutoDepositEntity.class,
                        parentColumns = "id",
                        childColumns = "auto_deposit_id",
                        onDelete = ForeignKey.SET_NULL
                )
        },
        indices = {
                @Index(value = {"goal_id"}),
                @Index(value = {"auto_deposit_id"}),
                @Index(value = {"transaction_date"}),
                @Index(value = {"transaction_type"}),
                @Index(value = {"category"})
        }
)
@TypeConverters(DateConverter.class)
public class TransactionEntity {

    public static final int TYPE_DEPOSIT = 1;     // Пополнение
    public static final int TYPE_WITHDRAWAL = 2;  // Списание
    public static final int TYPE_TRANSFER = 3;    // Перевод между целями
    public static final int TYPE_ADJUSTMENT = 4;  // Корректировка

    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "id")
    private String id = UUID.randomUUID().toString();

    @ColumnInfo(name = "goal_id")
    private String goalId;

    @ColumnInfo(name = "related_goal_id")
    private String relatedGoalId; // Для переводов между целями

    @ColumnInfo(name = "auto_deposit_id")
    private String autoDepositId;

    @ColumnInfo(name = "amount")
    private Double amount;

    @ColumnInfo(name = "currency", defaultValue = "RUB")
    private String currency = "RUB";

    @ColumnInfo(name = "transaction_type", defaultValue = "1")
    private Integer transactionType = TYPE_DEPOSIT;

    @ColumnInfo(name = "transaction_date")
    private Date transactionDate = new Date();

    @ColumnInfo(name = "description")
    private String description;

    @ColumnInfo(name = "category")
    private String category;

    @ColumnInfo(name = "created_at")
    private Date createdAt = new Date();

    @ColumnInfo(name = "updated_at")
    private Date updatedAt = new Date();

    @ColumnInfo(name = "notes")
    private String notes;

    @ColumnInfo(name = "is_synced", defaultValue = "0")
    private Boolean isSynced = false;

    @ColumnInfo(name = "is_recurring", defaultValue = "0")
    private Boolean isRecurring = false;

    @ColumnInfo(name = "recurring_id")
    private String recurringId;

    // Конструкторы
    public TransactionEntity() {
    }

    @Ignore
    public TransactionEntity(String goalId, Double amount, Integer transactionType) {
        this.goalId = goalId;
        this.amount = amount;
        this.transactionType = transactionType;
        this.transactionDate = new Date();
        this.createdAt = new Date();
        this.updatedAt = new Date();
    }

    @Ignore
    public TransactionEntity(String goalId, String autoDepositId, Double amount) {
        this.goalId = goalId;
        this.autoDepositId = autoDepositId;
        this.amount = amount;
        this.transactionType = TYPE_DEPOSIT;
        this.description = "Автопополнение";
        this.transactionDate = new Date();
        this.createdAt = new Date();
        this.updatedAt = new Date();
    }

    // Геттеры и сеттеры
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGoalId() {
        return goalId;
    }

    public void setGoalId(String goalId) {
        this.goalId = goalId;
        this.updatedAt = new Date();
    }

    public String getRelatedGoalId() {
        return relatedGoalId;
    }

    public void setRelatedGoalId(String relatedGoalId) {
        this.relatedGoalId = relatedGoalId;
        this.updatedAt = new Date();
    }

    public String getAutoDepositId() {
        return autoDepositId;
    }

    public void setAutoDepositId(String autoDepositId) {
        this.autoDepositId = autoDepositId;
        this.updatedAt = new Date();
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
        this.updatedAt = new Date();
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
        this.updatedAt = new Date();
    }

    public Integer getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(Integer transactionType) {
        this.transactionType = transactionType;
        this.updatedAt = new Date();
    }

    public Date getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(Date transactionDate) {
        this.transactionDate = transactionDate;
        this.updatedAt = new Date();
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
        this.updatedAt = new Date();
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
        this.updatedAt = new Date();
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
        this.updatedAt = new Date();
    }

    public Boolean getIsSynced() {
        return isSynced;
    }

    public void setIsSynced(Boolean synced) {
        isSynced = synced;
        this.updatedAt = new Date();
    }

    public Boolean getIsRecurring() {
        return isRecurring;
    }

    public void setIsRecurring(Boolean recurring) {
        isRecurring = recurring;
        this.updatedAt = new Date();
    }

    public String getRecurringId() {
        return recurringId;
    }

    public void setRecurringId(String recurringId) {
        this.recurringId = recurringId;
        this.updatedAt = new Date();
    }

    // Вспомогательные методы
    public String getTransactionTypeString() {
        switch (transactionType) {
            case TYPE_DEPOSIT: return "Пополнение";
            case TYPE_WITHDRAWAL: return "Списание";
            case TYPE_TRANSFER: return "Перевод";
            case TYPE_ADJUSTMENT: return "Корректировка";
            default: return "Неизвестно";
        }
    }

    public boolean isDeposit() {
        return transactionType == TYPE_DEPOSIT || transactionType == TYPE_TRANSFER;
    }

    public boolean isWithdrawal() {
        return transactionType == TYPE_WITHDRAWAL;
    }

    public Double getSignedAmount() {
        if (isDeposit()) {
            return Math.abs(amount);
        } else if (isWithdrawal()) {
            return -Math.abs(amount);
        }
        return amount;
    }

    @Override
    public String toString() {
        return "TransactionEntity{" +
                "id='" + id + '\'' +
                ", goalId='" + goalId + '\'' +
                ", amount=" + amount +
                ", type=" + getTransactionTypeString() +
                ", date=" + transactionDate +
                '}';
    }
}