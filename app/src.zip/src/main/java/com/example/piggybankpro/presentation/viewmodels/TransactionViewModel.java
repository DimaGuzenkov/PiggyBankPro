package com.example.piggybankpro.presentation.viewmodels;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.piggybankpro.data.local.entities.TransactionEntity;
import com.example.piggybankpro.data.repository.TransactionRepository;
import com.example.piggybankpro.data.repository.RepositoryFactory;

import java.util.Date;
import java.util.List;

public class TransactionViewModel extends AndroidViewModel {

    private TransactionRepository transactionRepository;
    private LiveData<List<TransactionEntity>> allTransactions;
    private MutableLiveData<TransactionEntity> selectedTransaction = new MutableLiveData<>();
    private MutableLiveData<Boolean> isLoading = new MutableLiveData<>(false);
    private MutableLiveData<String> errorMessage = new MutableLiveData<>();

    public TransactionViewModel(@NonNull Application application) {
        super(application);
        transactionRepository = RepositoryFactory.getInstance(application).getTransactionRepository();
        allTransactions = transactionRepository.getAllTransactions();
    }

    // Получение данных
    public LiveData<List<TransactionEntity>> getAllTransactions() {
        return allTransactions;
    }

    public LiveData<TransactionEntity> getTransactionById(String transactionId) {
        return transactionRepository.getTransactionById(transactionId);
    }

    // Фильтрация
    public LiveData<List<TransactionEntity>> getTransactionsByGoalId(String goalId) {
        return transactionRepository.getTransactionsByGoalId(goalId);
    }

    public LiveData<List<TransactionEntity>> getTransactionsByDepositId(String depositId) {
        return transactionRepository.getTransactionsByDepositId(depositId);
    }

    public LiveData<List<TransactionEntity>> getTransactionsByType(int transactionType) {
        return transactionRepository.getTransactionsByType(transactionType);
    }

    public LiveData<List<TransactionEntity>> getTransactionsBetween(Date startDate, Date endDate) {
        return transactionRepository.getTransactionsBetween(startDate, endDate);
    }

    public LiveData<List<TransactionEntity>> getTransactionsFromDate(Date startDate) {
        return transactionRepository.getTransactionsFromDate(startDate);
    }

    public LiveData<List<TransactionEntity>> getTransactionsToDate(Date endDate) {
        return transactionRepository.getTransactionsToDate(endDate);
    }

    // Пагинация
    public LiveData<List<TransactionEntity>> getRecentTransactions(int limit) {
        return transactionRepository.getRecentTransactions(limit);
    }

    public LiveData<List<TransactionEntity>> getRecentTransactionsForGoal(String goalId, int limit) {
        return transactionRepository.getRecentTransactionsForGoal(goalId, limit);
    }

    // Поиск
    public LiveData<List<TransactionEntity>> searchTransactions(String query) {
        return transactionRepository.searchTransactions(query);
    }

    // CRUD операции
    public void createTransaction(TransactionEntity transaction) {
        try {
            validateTransaction(transaction);
            transactionRepository.insert(transaction);
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при создании транзакции: " + e.getMessage());
        }
    }

    public void deleteTransaction(String transactionId) {
        try {
            transactionRepository.delete(transactionId);
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при удалении транзакции: " + e.getMessage());
        }
    }

    // Валидация
    private void validateTransaction(TransactionEntity transaction) throws Exception {
        if (transaction.getAmount() == null || transaction.getAmount() <= 0) {
            throw new Exception("Сумма должна быть больше нуля");
        }

        if (transaction.getGoalId() == null || transaction.getGoalId().trim().isEmpty()) {
            throw new Exception("Не указана цель");
        }

        if (transaction.getTransactionType() < 1 || transaction.getTransactionType() > 4) {
            throw new Exception("Неверный тип транзакции");
        }
    }

    // Статистика
    public LiveData<Integer> getTransactionCount() {
        return transactionRepository.getTransactionCount();
    }

    public LiveData<Integer> getTransactionCountForGoal(String goalId) {
        return transactionRepository.getTransactionCountForGoal(goalId);
    }

    public LiveData<Double> getTotalDepositsForGoal(String goalId) {
        return transactionRepository.getTotalDepositsForGoal(goalId);
    }

    public LiveData<Double> getTotalWithdrawalsForGoal(String goalId) {
        return transactionRepository.getTotalWithdrawalsForGoal(goalId);
    }

    public LiveData<Double> getNetAmountForGoal(String goalId) {
        return transactionRepository.getNetAmountForGoal(goalId);
    }

    public LiveData<Double> getTotalDepositsBetween(Date startDate, Date endDate) {
        return transactionRepository.getTotalDepositsBetween(startDate, endDate);
    }

    public LiveData<Double> getTotalWithdrawalsBetween(Date startDate, Date endDate) {
        return transactionRepository.getTotalWithdrawalsBetween(startDate, endDate);
    }

    // Аналитика
    public LiveData<List<com.example.piggybankpro.data.local.dao.TransactionDao.MonthSummary>> getMonthlySummary() {
        return transactionRepository.getMonthlySummary();
    }

    public LiveData<List<com.example.piggybankpro.data.local.dao.TransactionDao.CategorySummary>> getCategorySummary() {
        return transactionRepository.getCategorySummary();
    }

    // Получение и установка выбранной транзакции
    public LiveData<TransactionEntity> getSelectedTransaction() {
        return selectedTransaction;
    }

    public void setSelectedTransaction(TransactionEntity transaction) {
        selectedTransaction.setValue(transaction);
    }

    public void clearSelectedTransaction() {
        selectedTransaction.setValue(null);
    }

    // Состояние загрузки
    public LiveData<Boolean> getIsLoading() {
        return isLoading;
    }

    public void setLoading(boolean loading) {
        isLoading.setValue(loading);
    }

    // Ошибки
    public LiveData<String> getErrorMessage() {
        return errorMessage;
    }

    public void clearError() {
        errorMessage.setValue(null);
    }

    // Вспомогательные методы
    public String getTransactionTypeString(int transactionType) {
        switch (transactionType) {
            case TransactionEntity.TYPE_DEPOSIT: return "Пополнение";
            case TransactionEntity.TYPE_WITHDRAWAL: return "Списание";
            case TransactionEntity.TYPE_TRANSFER: return "Перевод";
            case TransactionEntity.TYPE_ADJUSTMENT: return "Корректировка";
            default: return "Неизвестно";
        }
    }

    public String formatDate(Date date) {
        if (date == null) return "";
        return android.text.format.DateFormat.getDateFormat(getApplication()).format(date);
    }

    public String formatDateTime(Date date) {
        if (date == null) return "";
        return android.text.format.DateFormat.getLongDateFormat(getApplication()).format(date) + " " +
                android.text.format.DateFormat.getTimeFormat(getApplication()).format(date);
    }
}