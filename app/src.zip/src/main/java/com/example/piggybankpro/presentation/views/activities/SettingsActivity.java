package com.example.piggybankpro.presentation.views.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.piggybankpro.R;
import com.example.piggybankpro.data.local.entities.SettingsEntity;
import com.example.piggybankpro.presentation.viewmodels.SettingsViewModel;
import com.google.android.material.slider.Slider;

public class SettingsActivity extends AppCompatActivity {

    private Switch switchNotifications;
    private Switch switchNotificationSound;
    private Switch switchVibration;
    private Spinner spinnerTheme;
    private Slider sliderTextSize;
    private TextView textViewTextSizeValue;
    private Spinner spinnerCurrency;
    private Switch switchBiometricAuth;
    private Switch switchAutoBackup;
    private Button buttonBackupNow;
    private Button buttonExportData;
    private Button buttonImportData;
    private Button buttonResetData;

    private SettingsViewModel settingsViewModel;
    private SettingsEntity currentSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Настройка Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Настройки");

        // Инициализация ViewModel
        settingsViewModel = new androidx.lifecycle.ViewModelProvider(this).get(SettingsViewModel.class);

        // Инициализация представлений
        initViews();

        // Настройка спиннеров
        setupSpinners();

        // Наблюдение за данными
        observeViewModel();

        // Настройка слушателей
        setupListeners();
    }

    private void initViews() {
        switchNotifications = findViewById(R.id.switch_notifications);
        switchNotificationSound = findViewById(R.id.switch_notification_sound);
        switchVibration = findViewById(R.id.switch_vibration);
        spinnerTheme = findViewById(R.id.spinner_theme);
        sliderTextSize = findViewById(R.id.slider_text_size);
        textViewTextSizeValue = findViewById(R.id.text_view_text_size_value);
        spinnerCurrency = findViewById(R.id.spinner_currency);
        switchBiometricAuth = findViewById(R.id.switch_biometric_auth);
        switchAutoBackup = findViewById(R.id.switch_auto_backup);
        buttonBackupNow = findViewById(R.id.button_backup_now);
        buttonExportData = findViewById(R.id.button_export_data);
        buttonImportData = findViewById(R.id.button_import_data);
        buttonResetData = findViewById(R.id.button_reset_data);
    }

    private void setupSpinners() {
        // Настройка темы
        ArrayAdapter<CharSequence> themeAdapter = ArrayAdapter.createFromResource(
                this,
                R.array.theme_options,
                android.R.layout.simple_spinner_item
        );
        themeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTheme.setAdapter(themeAdapter);

        // Настройка валюты
        ArrayAdapter<CharSequence> currencyAdapter = ArrayAdapter.createFromResource(
                this,
                R.array.currency_options,
                android.R.layout.simple_spinner_item
        );
        currencyAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCurrency.setAdapter(currencyAdapter);
    }

    private void observeViewModel() {
        // Подписка на настройки
        settingsViewModel.getSettings().observe(this, settings -> {
            if (settings != null) {
                currentSettings = settings;
                updateUI(settings);
            }
        });

        // Подписка на сообщения
        settingsViewModel.getSuccessMessage().observe(this, message -> {
            if (message != null) {
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                settingsViewModel.clearMessages();
            }
        });

        settingsViewModel.getErrorMessage().observe(this, message -> {
            if (message != null) {
                Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                settingsViewModel.clearMessages();
            }
        });
    }

    private void updateUI(SettingsEntity settings) {
        // Уведомления
        switchNotifications.setChecked(settings.getNotificationsEnabled());
        switchNotificationSound.setChecked(settings.getNotificationSoundEnabled());
        switchVibration.setChecked(settings.getVibrationEnabled());

        // Тема
        int themePosition = settings.getThemeMode() - 1; // Тема начинается с 1
        if (themePosition >= 0 && themePosition < spinnerTheme.getCount()) {
            spinnerTheme.setSelection(themePosition);
        }

        // Размер текста
        sliderTextSize.setValue(settings.getTextSize());
        textViewTextSizeValue.setText(String.valueOf(settings.getTextSize()));

        // Валюта
        String currency = settings.getCurrency();
        for (int i = 0; i < spinnerCurrency.getCount(); i++) {
            if (spinnerCurrency.getItemAtPosition(i).toString().contains(currency)) {
                spinnerCurrency.setSelection(i);
                break;
            }
        }

        // Биометрия
        switchBiometricAuth.setChecked(settings.getBiometricAuthEnabled());

        // Резервное копирование
        switchAutoBackup.setChecked(settings.getAutoBackupEnabled());
    }

    private void setupListeners() {
        // Слушатели для переключателей
        switchNotifications.setOnCheckedChangeListener((buttonView, isChecked) -> {
            settingsViewModel.updateNotificationsEnabled(isChecked);
        });

        switchNotificationSound.setOnCheckedChangeListener((buttonView, isChecked) -> {
            settingsViewModel.updateNotificationSoundEnabled(isChecked);
        });

        switchVibration.setOnCheckedChangeListener((buttonView, isChecked) -> {
            settingsViewModel.updateVibrationEnabled(isChecked);
        });

        // Слушатель для темы
        spinnerTheme.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                int themeMode = position + 1; // Тема начинается с 1
                settingsViewModel.updateThemeMode(themeMode);
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        // Слушатель для размера текста
        sliderTextSize.addOnChangeListener((slider, value, fromUser) -> {
            if (fromUser) {
                textViewTextSizeValue.setText(String.valueOf((int) value));
                settingsViewModel.updateTextSize((int) value);
            }
        });

        // Слушатель для валюты
        spinnerCurrency.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                String selected = parent.getItemAtPosition(position).toString();
                // Извлекаем код валюты (например, "RUB - Российский рубль" -> "RUB")
                String currency = selected.split(" ")[0];
                settingsViewModel.updateCurrency(currency);
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        // Слушатель для биометрии
        switchBiometricAuth.setOnCheckedChangeListener((buttonView, isChecked) -> {
            settingsViewModel.updateBiometricAuthEnabled(isChecked);
        });

        // Слушатель для автобэкапа
        switchAutoBackup.setOnCheckedChangeListener((buttonView, isChecked) -> {
            settingsViewModel.updateAutoBackupEnabled(isChecked);
        });

        // Кнопка резервного копирования сейчас
        buttonBackupNow.setOnClickListener(v -> {
            performBackup();
        });

        // Кнопка экспорта данных
        buttonExportData.setOnClickListener(v -> {
            exportData();
        });

        // Кнопка импорта данных
        buttonImportData.setOnClickListener(v -> {
            importData();
        });

        // Кнопка сброса данных
        buttonResetData.setOnClickListener(v -> {
            resetData();
        });
    }

    private void performBackup() {
        // TODO: Реализовать логику резервного копирования
        Toast.makeText(this, "Резервное копирование выполнено", Toast.LENGTH_SHORT).show();
    }

    private void exportData() {
        // TODO: Реализовать логику экспорта данных
        Toast.makeText(this, "Экспорт данных...", Toast.LENGTH_SHORT).show();
    }

    private void importData() {
        // TODO: Реализовать логику импорта данных
        Toast.makeText(this, "Импорт данных...", Toast.LENGTH_SHORT).show();
    }

    private void resetData() {
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);
        builder.setTitle("Сброс данных");
        builder.setMessage("Вы уверены, что хотите сбросить все данные приложения? Это действие нельзя отменить.");

        builder.setPositiveButton("Сбросить", (dialog, which) -> {
            // TODO: Реализовать сброс данных
            Toast.makeText(this, "Все данные сброшены", Toast.LENGTH_SHORT).show();
        });

        builder.setNegativeButton("Отмена", null);
        builder.show();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}