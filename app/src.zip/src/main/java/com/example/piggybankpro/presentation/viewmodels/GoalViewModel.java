package com.example.piggybankpro.presentation.viewmodels;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.piggybankpro.data.local.entities.GoalEntity;
import com.example.piggybankpro.data.repository.GoalRepository;
import com.example.piggybankpro.data.repository.RepositoryFactory;

import java.util.List;

public class GoalViewModel extends AndroidViewModel {

    private GoalRepository goalRepository;
    private LiveData<List<GoalEntity>> allGoals;
    private MutableLiveData<GoalEntity> selectedGoal = new MutableLiveData<>();
    private MutableLiveData<Boolean> isLoading = new MutableLiveData<>(false);
    private MutableLiveData<String> errorMessage = new MutableLiveData<>();

    public GoalViewModel(@NonNull Application application) {
        super(application);
        goalRepository = RepositoryFactory.getInstance(application).getGoalRepository();
        allGoals = goalRepository.getAllGoals();
    }

    // Получение данных
    public LiveData<List<GoalEntity>> getAllGoals() {
        return allGoals;
    }

    public LiveData<GoalEntity> getGoalById(String goalId) {
        return goalRepository.getGoalById(goalId);
    }

    public LiveData<List<GoalEntity>> getRootGoals() {
        return goalRepository.getRootGoals();
    }

    public LiveData<List<GoalEntity>> getSubGoals(String parentId) {
        return goalRepository.getSubGoals(parentId);
    }

    public LiveData<List<GoalEntity>> getDirectoryGoals() {
        return goalRepository.getDirectoryGoals();
    }

    public LiveData<List<GoalEntity>> getActiveGoals() {
        return goalRepository.getActiveGoals();
    }

    public LiveData<List<GoalEntity>> getCompletedGoals() {
        return goalRepository.getCompletedGoals();
    }

    public LiveData<List<GoalEntity>> searchGoals(String query) {
        return goalRepository.searchGoals(query);
    }

    // CRUD операции
    public void createGoal(GoalEntity goal) {
        try {
            goalRepository.insert(goal);
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при создании цели: " + e.getMessage());
        }
    }

    public void updateGoal(GoalEntity goal) {
        try {
            goalRepository.update(goal);
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при обновлении цели: " + e.getMessage());
        }
    }

    public void deleteGoal(GoalEntity goal) {
        try {
            goalRepository.delete(goal);
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при удалении цели: " + e.getMessage());
        }
    }

    public void deleteGoalById(String goalId) {
        try {
            goalRepository.deleteById(goalId);
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при удалении цели: " + e.getMessage());
        }
    }

    // Операции с суммами
    public void depositToGoal(String goalId, double amount, String description) {
        try {
            if (amount <= 0) {
                errorMessage.setValue("Сумма пополнения должна быть больше нуля");
                return;
            }
            goalRepository.deposit(goalId, amount, description);
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при пополнении: " + e.getMessage());
        }
    }

    public void withdrawFromGoal(String goalId, double amount, String description) {
        try {
            if (amount <= 0) {
                errorMessage.setValue("Сумма списания должна быть больше нуля");
                return;
            }
            goalRepository.withdraw(goalId, amount, description);
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при списании: " + e.getMessage());
        }
    }

    public void transferBetweenGoals(String fromGoalId, String toGoalId, double amount, String description) {
        try {
            if (amount <= 0) {
                errorMessage.setValue("Сумма перевода должна быть больше нуля");
                return;
            }
            goalRepository.transfer(fromGoalId, toGoalId, amount, description);
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при переводе: " + e.getMessage());
        }
    }

    // Управление иерархией
    public void moveGoalToDirectory(String goalId, String directoryId) {
        try {
            goalRepository.moveGoalToDirectory(goalId, directoryId);
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при перемещении цели: " + e.getMessage());
        }
    }

    public void removeGoalFromDirectory(String goalId) {
        try {
            goalRepository.removeFromDirectory(goalId);
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при удалении из директории: " + e.getMessage());
        }
    }

    // Изменение статусов
    public void archiveGoal(String goalId, boolean archive) {
        try {
            goalRepository.archiveGoal(goalId, archive);
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при изменении статуса архивации: " + e.getMessage());
        }
    }

    public void completeGoal(String goalId, boolean complete) {
        try {
            goalRepository.completeGoal(goalId, complete);
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при изменении статуса завершения: " + e.getMessage());
        }
    }

    // Статистика
    public LiveData<Integer> getGoalsCount() {
        return goalRepository.getGoalsCount();
    }

    public LiveData<Integer> getCompletedGoalsCount() {
        return goalRepository.getCompletedGoalsCount();
    }

    public LiveData<Double> getTotalSavedAmount() {
        return goalRepository.getTotalSavedAmount();
    }

    public LiveData<Double> getTotalTargetAmount() {
        return goalRepository.getTotalTargetAmount();
    }

    // Получение и установка выбранной цели
    public LiveData<GoalEntity> getSelectedGoal() {
        return selectedGoal;
    }

    public void setSelectedGoal(GoalEntity goal) {
        selectedGoal.setValue(goal);
    }

    public void clearSelectedGoal() {
        selectedGoal.setValue(null);
    }

    // Состояние загрузки
    public LiveData<Boolean> getIsLoading() {
        return isLoading;
    }

    public void setLoading(boolean loading) {
        isLoading.setValue(loading);
    }

    // Ошибки
    public LiveData<String> getErrorMessage() {
        return errorMessage;
    }

    public void clearError() {
        errorMessage.setValue(null);
    }

    // Вспомогательные методы
    public double calculateProgressPercentage(double current, double target) {
        if (target == 0) return 0;
        return (current / target) * 100;
    }

    public String formatCurrency(double amount) {
        return String.format("%.2f ₽", amount);
    }
}