package com.example.piggybankpro.presentation.views.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.piggybankpro.R;
import com.example.piggybankpro.data.local.entities.GoalEntity;
import com.example.piggybankpro.databinding.ActivityMainBinding;
import com.example.piggybankpro.presentation.adapters.GoalAdapter;
import com.example.piggybankpro.presentation.viewmodels.MainViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private MainViewModel mainViewModel;
    private GoalAdapter goalAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Инициализация ViewBinding
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Настройка Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Инициализация ViewModel
        mainViewModel = new ViewModelProvider(this).get(MainViewModel.class);

        // Настройка RecyclerView
        setupRecyclerView();

        // Наблюдение за данными
        observeViewModel();

        // Настройка FAB
        setupFloatingActionButton();

        // Загрузка данных
        loadData();
    }

    private void setupRecyclerView() {
        goalAdapter = new GoalAdapter(new ArrayList<>(), new GoalAdapter.OnGoalClickListener() {
            @Override
            public void onGoalClick(GoalEntity goal) {
                onGoalClicked(goal);
            }

            @Override
            public void onGoalLongClick(GoalEntity goal, View view) {
                // Обработка долгого нажатия (можно оставить пустым)
            }
        });
        binding.recyclerViewGoals.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerViewGoals.setAdapter(goalAdapter);

        // Добавляем разделитель между элементами
        binding.recyclerViewGoals.addItemDecoration(
                new androidx.recyclerview.widget.DividerItemDecoration(
                        this,
                        LinearLayoutManager.VERTICAL
                )
        );
    }

    private void observeViewModel() {
        // Подписка на список целей
        mainViewModel.getAllGoals().observe(this, goals -> {
            if (goals != null && !goals.isEmpty()) {
                goalAdapter.updateGoals(goals);
                binding.textViewEmptyState.setVisibility(View.GONE);
                binding.recyclerViewGoals.setVisibility(View.VISIBLE);
            } else {
                binding.textViewEmptyState.setVisibility(View.VISIBLE);
                binding.recyclerViewGoals.setVisibility(View.GONE);
                binding.textViewEmptyState.setText("У вас пока нет целей накопления\nНажмите + чтобы добавить первую");
            }
        });

        // Подписка на общую статистику
        mainViewModel.getTotalSavedAmount().observe(this, totalSaved -> {
            if (totalSaved != null) {
                binding.textViewTotalSaved.setText(mainViewModel.formatCurrency(totalSaved));
            }
        });

        mainViewModel.getTotalTargetAmount().observe(this, totalTarget -> {
            if (totalTarget != null) {
                binding.textViewTotalTarget.setText(mainViewModel.formatCurrency(totalTarget));
            }
        });

        mainViewModel.calculateOverallProgress().observe(this, progress -> {
            if (progress != null) {
                binding.progressBarOverall.setProgress((int) Math.min(progress, 100));
                binding.textViewProgressPercentage.setText(mainViewModel.formatPercentage(progress));
            }
        });
    }

    private void setupFloatingActionButton() {
        FloatingActionButton fab = findViewById(R.id.fab_add_goal);
        fab.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, CreateGoalActivity.class);
            startActivity(intent);
        });

        // Долгое нажатие для быстрого добавления
        fab.setOnLongClickListener(view -> {
            showQuickAddDialog();
            return true;
        });
    }

    private void loadData() {
        // Здесь можно добавить загрузку данных или инициализацию
        // Например, проверка первого запуска
    }

    private void onGoalClicked(com.example.piggybankpro.data.local.entities.GoalEntity goal) {
        // Открытие деталей цели
        Intent intent = new Intent(this, GoalDetailActivity.class);
        intent.putExtra("goal_id", goal.getId());
        startActivity(intent);
    }

    private void showQuickAddDialog() {
        // TODO: Реализовать диалог быстрого добавления цели
        Snackbar.make(binding.getRoot(), "Быстрое добавление цели", Snackbar.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Надуваем меню
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            openSettings();
            return true;
        } else if (id == R.id.action_auto_deposit) {
            openAutoDeposit();
            return true;
        } else if (id == R.id.action_statistics) {
//            openStatistics();
            return true;
        } else if (id == R.id.action_backup) {
            backupData();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void openSettings() {
        Intent intent = new Intent(this, SettingsActivity.class);
        startActivity(intent);
    }

    private void openAutoDeposit() {
        Intent intent = new Intent(this, AutoDepositActivity.class);
        startActivity(intent);
    }

//    private void openStatistics() {
//        Intent intent = new Intent(this, StatisticsActivity.class);
//        startActivity(intent);
//    }

    private void backupData() {
        // TODO: Реализовать резервное копирование
        Snackbar.make(binding.getRoot(), "Резервное копирование...", Snackbar.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Обновляем данные при возвращении на экран
        if (goalAdapter != null) {
            // Можно обновить данные
        }
    }
}