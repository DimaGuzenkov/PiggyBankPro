package com.example.piggybankpro.data.local.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.piggybankpro.data.local.entities.SettingsEntity;

@Dao
public interface SettingsDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(SettingsEntity settings);

    @Update
    void update(SettingsEntity settings);

    @Query("SELECT * FROM settings WHERE id = 1")
    LiveData<SettingsEntity> getSettings();

    @Query("SELECT * FROM settings WHERE id = 1")
    SettingsEntity getSettingsSync();

    // Обновление отдельных настроек
    @Query("UPDATE settings SET notifications_enabled = :enabled WHERE id = 1")
    void updateNotificationsEnabled(boolean enabled);

    @Query("UPDATE settings SET notification_sound_enabled = :enabled WHERE id = 1")
    void updateNotificationSoundEnabled(boolean enabled);

    @Query("UPDATE settings SET vibration_enabled = :enabled WHERE id = 1")
    void updateVibrationEnabled(boolean enabled);

    @Query("UPDATE settings SET theme_mode = :themeMode WHERE id = 1")
    void updateThemeMode(int themeMode);

    @Query("UPDATE settings SET text_size = :textSize WHERE id = 1")
    void updateTextSize(int textSize);

    @Query("UPDATE settings SET currency = :currency WHERE id = 1")
    void updateCurrency(String currency);

    @Query("UPDATE settings SET biometric_auth_enabled = :enabled WHERE id = 1")
    void updateBiometricAuthEnabled(boolean enabled);

    @Query("UPDATE settings SET auto_backup_enabled = :enabled WHERE id = 1")
    void updateAutoBackupEnabled(boolean enabled);

    @Query("UPDATE settings SET backup_frequency = :frequency WHERE id = 1")
    void updateBackupFrequency(int frequency);

    @Query("UPDATE settings SET last_backup_date = :backupDate WHERE id = 1")
    void updateLastBackupDate(long backupDate);
}
