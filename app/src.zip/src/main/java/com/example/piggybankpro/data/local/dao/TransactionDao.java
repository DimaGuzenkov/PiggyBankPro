package com.example.piggybankpro.data.local.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.piggybankpro.data.local.entities.TransactionEntity;

import java.util.List;

@Dao
public interface TransactionDao {

    // CRUD операции
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(TransactionEntity transaction);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<TransactionEntity> transactions);

    @Query("DELETE FROM transactions WHERE id = :transactionId")
    void delete(String transactionId);

    @Query("DELETE FROM transactions WHERE goal_id = :goalId")
    void deleteByGoalId(String goalId);

    @Query("DELETE FROM transactions WHERE auto_deposit_id = :depositId")
    void deleteByDepositId(String depositId);

    // Получение данных
    @Query("SELECT * FROM transactions ORDER BY transaction_date DESC")
    LiveData<List<TransactionEntity>> getAllTransactions();

    @Query("SELECT * FROM transactions WHERE id = :transactionId")
    LiveData<TransactionEntity> getTransactionById(String transactionId);

    @Query("SELECT * FROM transactions WHERE goal_id = :goalId ORDER BY transaction_date DESC")
    LiveData<List<TransactionEntity>> getTransactionsByGoalId(String goalId);

    @Query("SELECT * FROM transactions WHERE auto_deposit_id = :depositId ORDER BY transaction_date DESC")
    LiveData<List<TransactionEntity>> getTransactionsByDepositId(String depositId);

    @Query("SELECT * FROM transactions WHERE transaction_type = :transactionType ORDER BY transaction_date DESC")
    LiveData<List<TransactionEntity>> getTransactionsByType(int transactionType);

    // Фильтрация по дате
    @Query("SELECT * FROM transactions WHERE transaction_date BETWEEN :startDate AND :endDate ORDER BY transaction_date DESC")
    LiveData<List<TransactionEntity>> getTransactionsBetween(long startDate, long endDate);

    @Query("SELECT * FROM transactions WHERE transaction_date >= :startDate ORDER BY transaction_date DESC")
    LiveData<List<TransactionEntity>> getTransactionsFromDate(long startDate);

    @Query("SELECT * FROM transactions WHERE transaction_date <= :endDate ORDER BY transaction_date DESC")
    LiveData<List<TransactionEntity>> getTransactionsToDate(long endDate);

    // Пагинация
    @Query("SELECT * FROM transactions ORDER BY transaction_date DESC LIMIT :limit")
    LiveData<List<TransactionEntity>> getRecentTransactions(int limit);

    @Query("SELECT * FROM transactions WHERE goal_id = :goalId ORDER BY transaction_date DESC LIMIT :limit")
    LiveData<List<TransactionEntity>> getRecentTransactionsForGoal(String goalId, int limit);

    // Поиск
    @Query("SELECT * FROM transactions WHERE description LIKE '%' || :query || '%' ORDER BY transaction_date DESC")
    LiveData<List<TransactionEntity>> searchTransactions(String query);

    // Статистика
    @Query("SELECT COUNT(*) FROM transactions")
    LiveData<Integer> getTransactionCount();

    @Query("SELECT COUNT(*) FROM transactions WHERE goal_id = :goalId")
    LiveData<Integer> getTransactionCountForGoal(String goalId);

    @Query("SELECT SUM(amount) FROM transactions WHERE transaction_type = 1 AND goal_id = :goalId")
    LiveData<Double> getTotalDepositsForGoal(String goalId);

    @Query("SELECT SUM(amount) FROM transactions WHERE transaction_type = 2 AND goal_id = :goalId")
    LiveData<Double> getTotalWithdrawalsForGoal(String goalId);

    @Query("SELECT SUM(CASE WHEN transaction_type = 1 THEN amount ELSE -amount END) FROM transactions WHERE goal_id = :goalId")
    LiveData<Double> getNetAmountForGoal(String goalId);

    @Query("SELECT SUM(CASE WHEN transaction_type = 1 THEN amount ELSE 0 END) FROM transactions WHERE transaction_date BETWEEN :startDate AND :endDate")
    LiveData<Double> getTotalDepositsBetween(long startDate, long endDate);

    @Query("SELECT SUM(CASE WHEN transaction_type = 2 THEN amount ELSE 0 END) FROM transactions WHERE transaction_date BETWEEN :startDate AND :endDate")
    LiveData<Double> getTotalWithdrawalsBetween(long startDate, long endDate);

    // Группировка
    @Query("SELECT strftime('%Y-%m', transaction_date/1000, 'unixepoch') as month, SUM(CASE WHEN transaction_type = 1 THEN amount ELSE -amount END) as net_amount FROM transactions GROUP BY month ORDER BY month DESC")
    LiveData<List<MonthSummary>> getMonthlySummary();

    @Query("SELECT category, SUM(CASE WHEN transaction_type = 1 THEN amount ELSE -amount END) as net_amount FROM transactions GROUP BY category ORDER BY ABS(net_amount) DESC")
    LiveData<List<CategorySummary>> getCategorySummary();

    // Классы для группировки
    class MonthSummary {
        public String month;
        public Double net_amount;
    }

    class CategorySummary {
        public String category;
        public Double net_amount;
    }
}