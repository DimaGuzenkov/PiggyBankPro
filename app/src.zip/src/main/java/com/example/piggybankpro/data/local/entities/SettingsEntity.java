package com.example.piggybankpro.data.local.entities;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import com.example.piggybankpro.data.local.converters.DateConverter;

import java.util.Date;

@Entity(tableName = "settings")
@TypeConverters(DateConverter.class)
public class SettingsEntity {

    public static final int THEME_LIGHT = 1;
    public static final int THEME_DARK = 2;
    public static final int THEME_SYSTEM = 3;

    @PrimaryKey
    @ColumnInfo(name = "id")
    private Integer id = 1; // Всегда один экземпляр

    @ColumnInfo(name = "notifications_enabled", defaultValue = "1")
    private Boolean notificationsEnabled = true;

    @ColumnInfo(name = "notification_sound_enabled", defaultValue = "1")
    private Boolean notificationSoundEnabled = true;

    @ColumnInfo(name = "vibration_enabled", defaultValue = "1")
    private Boolean vibrationEnabled = true;

    @ColumnInfo(name = "theme_mode", defaultValue = "3")
    private Integer themeMode = THEME_SYSTEM;

    @ColumnInfo(name = "text_size", defaultValue = "16")
    private Integer textSize = 16;

    @ColumnInfo(name = "currency", defaultValue = "RUB")
    private String currency = "RUB";

    @ColumnInfo(name = "language", defaultValue = "ru")
    private String language = "ru";

    @ColumnInfo(name = "biometric_auth_enabled", defaultValue = "0")
    private Boolean biometricAuthEnabled = false;

    @ColumnInfo(name = "auto_backup_enabled", defaultValue = "0")
    private Boolean autoBackupEnabled = false;

    @ColumnInfo(name = "backup_frequency", defaultValue = "7")
    private Integer backupFrequency = 7; // Дни

    @ColumnInfo(name = "last_backup_date")
    private Date lastBackupDate;

    @ColumnInfo(name = "created_at")
    private Date createdAt = new Date();

    @ColumnInfo(name = "updated_at")
    private Date updatedAt = new Date();

    // Конструкторы
    public SettingsEntity() {
    }

    // Геттеры и сеттеры
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Boolean getNotificationsEnabled() {
        return notificationsEnabled;
    }

    public void setNotificationsEnabled(Boolean notificationsEnabled) {
        this.notificationsEnabled = notificationsEnabled;
        this.updatedAt = new Date();
    }

    public Boolean getNotificationSoundEnabled() {
        return notificationSoundEnabled;
    }

    public void setNotificationSoundEnabled(Boolean notificationSoundEnabled) {
        this.notificationSoundEnabled = notificationSoundEnabled;
        this.updatedAt = new Date();
    }

    public Boolean getVibrationEnabled() {
        return vibrationEnabled;
    }

    public void setVibrationEnabled(Boolean vibrationEnabled) {
        this.vibrationEnabled = vibrationEnabled;
        this.updatedAt = new Date();
    }

    public Integer getThemeMode() {
        return themeMode;
    }

    public void setThemeMode(Integer themeMode) {
        this.themeMode = themeMode;
        this.updatedAt = new Date();
    }

    public Integer getTextSize() {
        return textSize;
    }

    public void setTextSize(Integer textSize) {
        this.textSize = textSize;
        this.updatedAt = new Date();
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
        this.updatedAt = new Date();
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
        this.updatedAt = new Date();
    }

    public Boolean getBiometricAuthEnabled() {
        return biometricAuthEnabled;
    }

    public void setBiometricAuthEnabled(Boolean biometricAuthEnabled) {
        this.biometricAuthEnabled = biometricAuthEnabled;
        this.updatedAt = new Date();
    }

    public Boolean getAutoBackupEnabled() {
        return autoBackupEnabled;
    }

    public void setAutoBackupEnabled(Boolean autoBackupEnabled) {
        this.autoBackupEnabled = autoBackupEnabled;
        this.updatedAt = new Date();
    }

    public Integer getBackupFrequency() {
        return backupFrequency;
    }

    public void setBackupFrequency(Integer backupFrequency) {
        this.backupFrequency = backupFrequency;
        this.updatedAt = new Date();
    }

    public Date getLastBackupDate() {
        return lastBackupDate;
    }

    public void setLastBackupDate(Date lastBackupDate) {
        this.lastBackupDate = lastBackupDate;
        this.updatedAt = new Date();
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    // Вспомогательные методы
    public String getThemeModeString() {
        switch (themeMode) {
            case THEME_LIGHT: return "Светлая";
            case THEME_DARK: return "Темная";
            case THEME_SYSTEM: return "Системная";
            default: return "Неизвестно";
        }
    }

    public boolean shouldBackupNow() {
        if (!autoBackupEnabled || lastBackupDate == null) {
            return false;
        }

        long daysSinceLastBackup = (new Date().getTime() - lastBackupDate.getTime()) / (1000 * 60 * 60 * 24);
        return daysSinceLastBackup >= backupFrequency;
    }
}