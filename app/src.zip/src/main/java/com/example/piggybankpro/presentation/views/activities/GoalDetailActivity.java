package com.example.piggybankpro.presentation.views.activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.piggybankpro.R;
import com.example.piggybankpro.data.local.entities.GoalEntity;
import com.example.piggybankpro.data.local.entities.TransactionEntity;
import com.example.piggybankpro.presentation.adapters.TransactionAdapter;
import com.example.piggybankpro.presentation.viewmodels.GoalViewModel;
import com.example.piggybankpro.presentation.viewmodels.TransactionViewModel;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class GoalDetailActivity extends AppCompatActivity {

    private TextView textViewTitle;
    private TextView textViewDescription;
    private TextView textViewTargetAmount;
    private TextView textViewCurrentAmount;
    private TextView textViewProgressPercentage;
    private TextView textViewDaysLeft;
    private TextView textViewAmountNeeded;
    private TextView textViewTargetDate;
    private ProgressBar progressBarGoal;
    private MaterialCardView cardViewProgress;
    private MaterialButton buttonDeposit;
    private MaterialButton buttonWithdraw;
    private RecyclerView recyclerViewTransactions;

    private GoalViewModel goalViewModel;
    private TransactionViewModel transactionViewModel;
    private TransactionAdapter transactionAdapter;

    private String goalId;
    private GoalEntity currentGoal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal_detail);

        // Получение ID цели из Intent
        goalId = getIntent().getStringExtra("goal_id");
        if (goalId == null) {
            Toast.makeText(this, "Ошибка: цель не найдена", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Инициализация Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Детали цели");

        // Инициализация ViewModels
        goalViewModel = new ViewModelProvider(this).get(GoalViewModel.class);
        transactionViewModel = new ViewModelProvider(this).get(TransactionViewModel.class);

        // Инициализация представлений
        initViews();

        // Настройка RecyclerView для транзакций
        setupRecyclerView();

        // Наблюдение за данными
        observeData();

        // Настройка кнопок
        setupButtons();

        // Загрузка данных
        loadGoalData();
        loadTransactions();
    }

    private void initViews() {
        textViewTitle = findViewById(R.id.text_view_title);
        textViewDescription = findViewById(R.id.text_view_description);
        textViewTargetAmount = findViewById(R.id.text_view_target_amount);
        textViewCurrentAmount = findViewById(R.id.text_view_current_amount);
        textViewProgressPercentage = findViewById(R.id.text_view_progress_percentage);
        textViewDaysLeft = findViewById(R.id.text_view_days_left);
        textViewAmountNeeded = findViewById(R.id.text_view_amount_needed);
        textViewTargetDate = findViewById(R.id.text_view_target_date);
        progressBarGoal = findViewById(R.id.progress_bar_goal);
        cardViewProgress = findViewById(R.id.card_view_progress);
        buttonDeposit = findViewById(R.id.button_deposit);
        buttonWithdraw = findViewById(R.id.button_withdraw);
        recyclerViewTransactions = findViewById(R.id.recycler_view_transactions);
    }

    private void setupRecyclerView() {
        transactionAdapter = new TransactionAdapter(new ArrayList<>());
        recyclerViewTransactions.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewTransactions.setAdapter(transactionAdapter);

        // Добавляем разделитель между элементами
        recyclerViewTransactions.addItemDecoration(
                new androidx.recyclerview.widget.DividerItemDecoration(
                        this,
                        LinearLayoutManager.VERTICAL
                )
        );
    }

    private void setupButtons() {
        buttonDeposit.setOnClickListener(v -> showDepositDialog());
        buttonWithdraw.setOnClickListener(v -> showWithdrawDialog());
    }

    private void observeData() {
        // Наблюдение за ошибками
        goalViewModel.getErrorMessage().observe(this, errorMessage -> {
            if (errorMessage != null) {
                Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show();
                goalViewModel.clearError();
            }
        });

        transactionViewModel.getErrorMessage().observe(this, errorMessage -> {
            if (errorMessage != null) {
                Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show();
                transactionViewModel.clearError();
            }
        });
    }

    private void loadGoalData() {
        goalViewModel.getGoalById(goalId).observe(this, goal -> {
            if (goal != null) {
                currentGoal = goal;
                updateUI(goal);
            }
        });
    }

    private void loadTransactions() {
        transactionViewModel.getTransactionsByGoalId(goalId).observe(this, transactions -> {
            if (transactions != null && !transactions.isEmpty()) {
                transactionAdapter.updateTransactions(transactions);
            } else {
                // Показываем заглушку, если транзакций нет
                transactionAdapter.updateTransactions(new ArrayList<>());
            }
        });
    }

    private void updateUI(GoalEntity goal) {
        // Основная информация
        textViewTitle.setText(goal.getTitle());
        textViewDescription.setText(goal.getDescription() != null ? goal.getDescription() : "Нет описания");

        // Суммы
        textViewTargetAmount.setText(formatCurrency(goal.getTargetAmount() != null ? goal.getTargetAmount() : 0));
        textViewCurrentAmount.setText(formatCurrency(goal.getCurrentAmount()));

        // Прогресс
        double progress = goal.getProgressPercentage() != null ? goal.getProgressPercentage() : 0;
        textViewProgressPercentage.setText(String.format(Locale.getDefault(), "%.1f%%", progress));
        progressBarGoal.setProgress((int) Math.min(progress, 100));

        // Устанавливаем цвет прогресс-бара в зависимости от прогресса
        if (progress < 30) {
            progressBarGoal.setProgressTintList(android.content.res.ColorStateList.valueOf(
                    getResources().getColor(R.color.progress_low, null)
            ));
        } else if (progress < 70) {
            progressBarGoal.setProgressTintList(android.content.res.ColorStateList.valueOf(
                    getResources().getColor(R.color.progress_medium, null)
            ));
        } else {
            progressBarGoal.setProgressTintList(android.content.res.ColorStateList.valueOf(
                    getResources().getColor(R.color.progress_high, null)
            ));
        }

        // Дни до цели
        Long daysLeft = goal.getDaysRemaining();
        if (daysLeft != null) {
            textViewDaysLeft.setText(formatDays(daysLeft));
        } else {
            textViewDaysLeft.setText("Дата не указана");
        }

        // Оставшаяся сумма
        Double amountNeeded = goal.getAmountNeeded();
        if (amountNeeded != null && amountNeeded > 0) {
            textViewAmountNeeded.setText(formatCurrency(amountNeeded));
        } else if (amountNeeded != null && amountNeeded <= 0) {
            textViewAmountNeeded.setText("Цель достигнута!");
            cardViewProgress.setCardBackgroundColor(
                    getResources().getColor(R.color.success_light, null)
            );
        } else {
            textViewAmountNeeded.setText("Нет целевой суммы");
        }

        // Дата цели
        if (goal.getTargetDate() != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy", Locale.getDefault());
            textViewTargetDate.setText(sdf.format(goal.getTargetDate()));
        } else {
            textViewTargetDate.setText("Дата не указана");
        }
    }

    private void showDepositDialog() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Пополнение цели");

        // Создаем layout для диалога
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_deposit_withdraw, null);
        builder.setView(dialogView);

        TextView textViewTitle = dialogView.findViewById(R.id.text_view_dialog_title);
        EditText editTextAmount = dialogView.findViewById(R.id.edit_text_amount);
        EditText editTextDescription = dialogView.findViewById(R.id.edit_text_description);

        textViewTitle.setText("Введите сумму пополнения:");
        editTextAmount.setHint("Сумма");

        builder.setPositiveButton("Пополнить", (dialog, which) -> {
            String amountStr = editTextAmount.getText().toString().trim();
            String description = editTextDescription.getText().toString().trim();

            if (!amountStr.isEmpty()) {
                try {
                    double amount = Double.parseDouble(amountStr);
                    if (amount > 0) {
                        goalViewModel.depositToGoal(goalId, amount, description);
                        Toast.makeText(this, "Цель пополнена", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Сумма должна быть больше нуля", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Неверный формат суммы", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Введите сумму", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Отмена", null);

        builder.show();
    }

    private void showWithdrawDialog() {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Списание с цели");

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_deposit_withdraw, null);
        builder.setView(dialogView);

        TextView textViewTitle = dialogView.findViewById(R.id.text_view_dialog_title);
        EditText editTextAmount = dialogView.findViewById(R.id.edit_text_amount);
        EditText editTextDescription = dialogView.findViewById(R.id.edit_text_description);

        textViewTitle.setText("Введите сумму списания:");
        editTextAmount.setHint("Сумма");

        builder.setPositiveButton("Списать", (dialog, which) -> {
            String amountStr = editTextAmount.getText().toString().trim();
            String description = editTextDescription.getText().toString().trim();

            if (!amountStr.isEmpty()) {
                try {
                    double amount = Double.parseDouble(amountStr);
                    if (amount > 0) {
                        // Проверяем, достаточно ли средств
                        if (currentGoal != null && currentGoal.getCurrentAmount() >= amount) {
                            goalViewModel.withdrawFromGoal(goalId, amount, description);
                            Toast.makeText(this, "Средства списаны", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(this, "Недостаточно средств", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(this, "Сумма должна быть больше нуля", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Неверный формат суммы", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Введите сумму", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Отмена", null);

        builder.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_goal_detail, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        } else if (id == R.id.action_edit) {
            editGoal();
            return true;
        } else if (id == R.id.action_delete) {
            deleteGoal();
            return true;
        } else if (id == R.id.action_share) {
            shareGoal();
            return true;
        } else if (id == R.id.action_archive) {
            archiveGoal();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void editGoal() {
        Intent intent = new Intent(this, CreateGoalActivity.class);
        intent.putExtra("goal_id", goalId);
        startActivity(intent);
    }

    private void deleteGoal() {
        new AlertDialog.Builder(this)
                .setTitle("Удаление цели")
                .setMessage("Вы уверены, что хотите удалить эту цель? Все связанные транзакции также будут удалены.")
                .setPositiveButton("Удалить", (dialog, which) -> {
                    if (currentGoal != null) {
                        goalViewModel.deleteGoal(currentGoal);
                        Toast.makeText(this, "Цель удалена", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void shareGoal() {
        if (currentGoal == null) return;

        String shareText = String.format(Locale.getDefault(),
                "Цель накопления: %s\n" +
                        "Текущая сумма: %.2f ₽\n" +
                        "Целевая сумма: %.2f ₽\n" +
                        "Прогресс: %.1f%%\n\n" +
                        "Создано в PiggyBank Pro",
                currentGoal.getTitle(),
                currentGoal.getCurrentAmount(),
                currentGoal.getTargetAmount() != null ? currentGoal.getTargetAmount() : 0,
                currentGoal.getProgressPercentage() != null ? currentGoal.getProgressPercentage() : 0
        );

        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Моя цель накопления");
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareText);

        startActivity(Intent.createChooser(shareIntent, "Поделиться целью"));
    }

    private void archiveGoal() {
        if (currentGoal == null) return;

        boolean newArchiveStatus = !currentGoal.getIsArchived();
        String message = newArchiveStatus ?
                "Цель будет перемещена в архив" :
                "Цель будет восстановлена из архива";

        new AlertDialog.Builder(this)
                .setTitle(newArchiveStatus ? "Архивировать цель" : "Восстановить цель")
                .setMessage(message)
                .setPositiveButton("OK", (dialog, which) -> {
                    goalViewModel.archiveGoal(goalId, newArchiveStatus);
                    String toastMessage = newArchiveStatus ?
                            "Цель архивирована" :
                            "Цель восстановлена";
                    Toast.makeText(this, toastMessage, Toast.LENGTH_SHORT).show();

                    if (newArchiveStatus) {
                        finish(); // Закрываем активность при архивации
                    }
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private String formatCurrency(double amount) {
        return String.format(Locale.getDefault(), "%.2f ₽", amount);
    }

    private String formatDays(long days) {
        if (days == 0) {
            return "Сегодня";
        } else if (days == 1) {
            return "1 день";
        } else if (days < 5) {
            return days + " дня";
        } else if (days < 21) {
            return days + " дней";
        } else {
            long weeks = days / 7;
            if (weeks == 1) return "1 неделя";
            if (weeks < 5) return weeks + " недели";
            return weeks + " недель";
        }
    }
}