package com.example.piggybankpro.data.local.entities;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.Index;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import com.example.piggybankpro.data.local.converters.DateConverter;

import java.util.Date;
import java.util.UUID;

@Entity(
        tableName = "auto_deposits",
        indices = {
                @Index(value = {"is_active"}),
                @Index(value = {"next_execution_date"})
        }
)
@TypeConverters(DateConverter.class)
public class AutoDepositEntity {

    public static final int TYPE_FIXED = 1;
    public static final int TYPE_PERCENTAGE = 2;

    public static final int PERIOD_DAILY = 1;
    public static final int PERIOD_WEEKLY = 2;
    public static final int PERIOD_BIWEEKLY = 3;
    public static final int PERIOD_MONTHLY = 4;
    public static final int PERIOD_QUARTERLY = 5;
    public static final int PERIOD_YEARLY = 6;

    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "id")
    private String id = UUID.randomUUID().toString();

    @ColumnInfo(name = "name")
    private String name;

    @ColumnInfo(name = "amount")
    private Double amount;

    @ColumnInfo(name = "deposit_type", defaultValue = "1")
    private Integer depositType = TYPE_FIXED; // 1 - фиксированная, 2 - процент

    @ColumnInfo(name = "percentage")
    private Double percentage; // Процент от общей суммы

    @ColumnInfo(name = "period_type", defaultValue = "4")
    private Integer periodType = PERIOD_MONTHLY;

    @ColumnInfo(name = "specific_day")
    private Integer specificDay; // Конкретный день (например, 15 число месяца)

    @ColumnInfo(name = "start_date")
    private Date startDate = new Date();

    @ColumnInfo(name = "end_date")
    private Date endDate;

    @ColumnInfo(name = "next_execution_date")
    private Date nextExecutionDate;

    @ColumnInfo(name = "last_execution_date")
    private Date lastExecutionDate;

    @ColumnInfo(name = "is_active", defaultValue = "1")
    private Boolean isActive = true;

    @ColumnInfo(name = "created_at")
    private Date createdAt = new Date();

    @ColumnInfo(name = "updated_at")
    private Date updatedAt = new Date();

    @ColumnInfo(name = "notes")
    private String notes;

    // Конструкторы
    public AutoDepositEntity() {
        calculateNextExecution();
    }

    @Ignore
    public AutoDepositEntity(String name, Double amount, Integer periodType) {
        this.name = name;
        this.amount = amount;
        this.periodType = periodType;
        this.createdAt = new Date();
        this.updatedAt = new Date();
        calculateNextExecution();
    }

    // Геттеры и сеттеры
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
        this.updatedAt = new Date();
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
        this.updatedAt = new Date();
    }

    public Integer getDepositType() {
        return depositType;
    }

    public void setDepositType(Integer depositType) {
        this.depositType = depositType;
        this.updatedAt = new Date();
    }

    public Double getPercentage() {
        return percentage;
    }

    public void setPercentage(Double percentage) {
        this.percentage = percentage;
        this.updatedAt = new Date();
    }

    public Integer getPeriodType() {
        return periodType;
    }

    public void setPeriodType(Integer periodType) {
        this.periodType = periodType;
        this.updatedAt = new Date();
        calculateNextExecution();
    }

    public Integer getSpecificDay() {
        return specificDay;
    }

    public void setSpecificDay(Integer specificDay) {
        this.specificDay = specificDay;
        this.updatedAt = new Date();
        calculateNextExecution();
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
        this.updatedAt = new Date();
        calculateNextExecution();
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
        this.updatedAt = new Date();
    }

    public Date getNextExecutionDate() {
        return nextExecutionDate;
    }

    public void setNextExecutionDate(Date nextExecutionDate) {
        this.nextExecutionDate = nextExecutionDate;
        this.updatedAt = new Date();
    }

    public Date getLastExecutionDate() {
        return lastExecutionDate;
    }

    public void setLastExecutionDate(Date lastExecutionDate) {
        this.lastExecutionDate = lastExecutionDate;
        this.updatedAt = new Date();
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean active) {
        isActive = active;
        this.updatedAt = new Date();
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
        this.updatedAt = new Date();
    }

    // Вспомогательные методы
    private void calculateNextExecution() {
        if (startDate == null) {
            startDate = new Date();
        }

        Date now = new Date();
        if (nextExecutionDate != null && nextExecutionDate.after(now)) {
            return; // Не пересчитываем если следующее выполнение еще в будущем
        }

        long time = startDate.getTime();

        switch (periodType) {
            case PERIOD_DAILY:
                time += 24 * 60 * 60 * 1000L;
                break;
            case PERIOD_WEEKLY:
                time += 7 * 24 * 60 * 60 * 1000L;
                break;
            case PERIOD_BIWEEKLY:
                time += 14 * 24 * 60 * 60 * 1000L;
                break;
            case PERIOD_MONTHLY:
                // Упрощенный расчет - всегда +30 дней
                time += 30L * 24 * 60 * 60 * 1000;
                break;
            case PERIOD_QUARTERLY:
                time += 90L * 24 * 60 * 60 * 1000;
                break;
            case PERIOD_YEARLY:
                time += 365L * 24 * 60 * 60 * 1000;
                break;
        }

        nextExecutionDate = new Date(time);
    }

    public void execute() {
        this.lastExecutionDate = new Date();
        calculateNextExecution();
        this.updatedAt = new Date();
    }

    public boolean isTimeToExecute() {
        if (!isActive) return false;
        if (endDate != null && new Date().after(endDate)) return false;

        return nextExecutionDate != null && nextExecutionDate.before(new Date());
    }

    public String getPeriodTypeString() {
        switch (periodType) {
            case PERIOD_DAILY: return "Ежедневно";
            case PERIOD_WEEKLY: return "Еженедельно";
            case PERIOD_BIWEEKLY: return "Раз в две недели";
            case PERIOD_MONTHLY: return "Ежемесячно";
            case PERIOD_QUARTERLY: return "Ежеквартально";
            case PERIOD_YEARLY: return "Ежегодно";
            default: return "Не указано";
        }
    }

    public String getDepositTypeString() {
        return depositType == TYPE_FIXED ? "Фиксированная сумма" : "Процент";
    }
}