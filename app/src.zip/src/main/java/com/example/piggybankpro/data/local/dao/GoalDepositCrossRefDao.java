package com.example.piggybankpro.data.local.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.piggybankpro.data.local.entities.GoalDepositCrossRefEntity;

import java.util.List;

@Dao
public interface GoalDepositCrossRefDao {

    // CRUD операции
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(GoalDepositCrossRefEntity crossRef);

    @Delete
    void delete(GoalDepositCrossRefEntity crossRef);

    @Query("DELETE FROM goal_deposit_cross_ref WHERE goal_id = :goalId AND auto_deposit_id = :depositId")
    void delete(String goalId, String depositId);

    @Query("DELETE FROM goal_deposit_cross_ref WHERE auto_deposit_id = :depositId")
    void deleteByDepositId(String depositId);

    @Query("DELETE FROM goal_deposit_cross_ref WHERE goal_id = :goalId")
    void deleteByGoalId(String goalId);

    // Получение данных
    @Query("SELECT * FROM goal_deposit_cross_ref WHERE auto_deposit_id = :depositId")
    LiveData<List<GoalDepositCrossRefEntity>> getCrossRefsByDepositId(String depositId);

    @Query("SELECT * FROM goal_deposit_cross_ref WHERE goal_id = :goalId")
    LiveData<List<GoalDepositCrossRefEntity>> getCrossRefsByGoalId(String goalId);

    @Query("SELECT * FROM goal_deposit_cross_ref WHERE auto_deposit_id = :depositId AND goal_id = :goalId")
    LiveData<GoalDepositCrossRefEntity> getCrossRef(String depositId, String goalId);

    // Обновление
    @Query("UPDATE goal_deposit_cross_ref SET amount = :amount WHERE auto_deposit_id = :depositId AND goal_id = :goalId")
    void updateAmount(String depositId, String goalId, Double amount);

    @Query("UPDATE goal_deposit_cross_ref SET percentage = :percentage WHERE auto_deposit_id = :depositId AND goal_id = :goalId")
    void updatePercentage(String depositId, String goalId, Double percentage);

    @Query("UPDATE goal_deposit_cross_ref SET distribution_type = :distributionType WHERE auto_deposit_id = :depositId AND goal_id = :goalId")
    void updateDistributionType(String depositId, String goalId, Integer distributionType);

    // Статистика
    @Query("SELECT COUNT(*) FROM goal_deposit_cross_ref WHERE auto_deposit_id = :depositId")
    LiveData<Integer> getGoalCountForDeposit(String depositId);

    @Query("SELECT COUNT(*) FROM goal_deposit_cross_ref WHERE goal_id = :goalId")
    LiveData<Integer> getDepositCountForGoal(String goalId);

    // Проверки
    @Query("SELECT EXISTS(SELECT 1 FROM goal_deposit_cross_ref WHERE auto_deposit_id = :depositId AND goal_id = :goalId)")
    boolean exists(String depositId, String goalId);
}
