package com.example.piggybankpro.presentation.viewmodels;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;

import com.example.piggybankpro.data.local.entities.GoalEntity;

public class SharedViewModel extends AndroidViewModel {

    private MutableLiveData<GoalEntity> selectedGoalForOperation = new MutableLiveData<>();
    private MutableLiveData<Double> quickEditAmount = new MutableLiveData<>();
    private MutableLiveData<Boolean> isQuickEditDeposit = new MutableLiveData<>(true);
    private MutableLiveData<String> quickEditDescription = new MutableLiveData<>();

    public SharedViewModel(@NonNull Application application) {
        super(application);
    }

    // Быстрое редактирование цели
    public MutableLiveData<GoalEntity> getSelectedGoalForOperation() {
        return selectedGoalForOperation;
    }

    public void setSelectedGoalForOperation(GoalEntity goal) {
        selectedGoalForOperation.setValue(goal);
    }

    public void clearSelectedGoalForOperation() {
        selectedGoalForOperation.setValue(null);
    }

    // Сумма для быстрого редактирования
    public MutableLiveData<Double> getQuickEditAmount() {
        return quickEditAmount;
    }

    public void setQuickEditAmount(Double amount) {
        quickEditAmount.setValue(amount);
    }

    public void clearQuickEditAmount() {
        quickEditAmount.setValue(null);
    }

    // Тип операции (пополнение/списание)
    public MutableLiveData<Boolean> getIsQuickEditDeposit() {
        return isQuickEditDeposit;
    }

    public void setIsQuickEditDeposit(boolean isDeposit) {
        isQuickEditDeposit.setValue(isDeposit);
    }

    // Описание для быстрого редактирования
    public MutableLiveData<String> getQuickEditDescription() {
        return quickEditDescription;
    }

    public void setQuickEditDescription(String description) {
        quickEditDescription.setValue(description);
    }

    public void clearQuickEditDescription() {
        quickEditDescription.setValue(null);
    }

    // Сброс всех данных быстрого редактирования
    public void resetQuickEdit() {
        clearSelectedGoalForOperation();
        clearQuickEditAmount();
        clearQuickEditDescription();
        isQuickEditDeposit.setValue(true);
    }

    // Вспомогательные методы
    public boolean validateQuickEdit() {
        if (selectedGoalForOperation.getValue() == null) {
            return false;
        }

        Double amount = quickEditAmount.getValue();
        if (amount == null || amount <= 0) {
            return false;
        }

        // Проверка для списания
        if (!isQuickEditDeposit.getValue()) {
            GoalEntity goal = selectedGoalForOperation.getValue();
            if (goal.getCurrentAmount() < amount) {
                return false;
            }
        }

        return true;
    }
}