package com.example.piggybankpro.data.local.database;

import android.content.Context;

import androidx.room.Room;

import com.example.piggybankpro.data.local.dao.AutoDepositDao;
import com.example.piggybankpro.data.local.dao.GoalDao;
import com.example.piggybankpro.data.local.dao.GoalDepositCrossRefDao;
import com.example.piggybankpro.data.local.dao.SettingsDao;
import com.example.piggybankpro.data.local.dao.TransactionDao;

public class DatabaseClient {

    private static DatabaseClient instance;
    private final AppDatabase appDatabase;

    private DatabaseClient(Context context) {
        appDatabase = Room.databaseBuilder(
                context.getApplicationContext(),
                AppDatabase.class,
                "savings_goals_db"
        ).build();
    }

    public static synchronized DatabaseClient getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseClient(context);
        }
        return instance;
    }

    public AppDatabase getAppDatabase() {
        return appDatabase;
    }

    public GoalDao getGoalDao() {
        return appDatabase.goalDao();
    }

    public AutoDepositDao getAutoDepositDao() {
        return appDatabase.autoDepositDao();
    }

    public GoalDepositCrossRefDao getGoalDepositCrossRefDao() {
        return appDatabase.goalDepositCrossRefDao();
    }

    public TransactionDao getTransactionDao() {
        return appDatabase.transactionDao();
    }

    public SettingsDao getSettingsDao() {
        return appDatabase.settingsDao();
    }
}
