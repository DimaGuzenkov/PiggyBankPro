package com.example.piggybankpro.data.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.piggybankpro.data.local.database.AppDatabase;
import com.example.piggybankpro.data.local.database.DatabaseClient;
import com.example.piggybankpro.data.local.dao.TransactionDao;
import com.example.piggybankpro.data.local.entities.TransactionEntity;

import java.util.Date;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class TransactionRepository {

    private TransactionDao transactionDao;
    private Executor executor;

    public TransactionRepository(Application application) {
        AppDatabase database = DatabaseClient.getInstance(application).getAppDatabase();
        transactionDao = database.transactionDao();
        executor = Executors.newSingleThreadExecutor();
    }

    // Основные операции
    public LiveData<List<TransactionEntity>> getAllTransactions() {
        return transactionDao.getAllTransactions();
    }

    public LiveData<TransactionEntity> getTransactionById(String transactionId) {
        return transactionDao.getTransactionById(transactionId);
    }

    public void insert(TransactionEntity transaction) {
        executor.execute(() -> {
            transactionDao.insert(transaction);
        });
    }

    public void delete(String transactionId) {
        executor.execute(() -> {
            transactionDao.delete(transactionId);
        });
    }

    // Фильтрация
    public LiveData<List<TransactionEntity>> getTransactionsByGoalId(String goalId) {
        return transactionDao.getTransactionsByGoalId(goalId);
    }

    public LiveData<List<TransactionEntity>> getTransactionsByDepositId(String depositId) {
        return transactionDao.getTransactionsByDepositId(depositId);
    }

    public LiveData<List<TransactionEntity>> getTransactionsByType(int transactionType) {
        return transactionDao.getTransactionsByType(transactionType);
    }

    // Фильтрация по дате
    public LiveData<List<TransactionEntity>> getTransactionsBetween(Date startDate, Date endDate) {
        return transactionDao.getTransactionsBetween(startDate.getTime(), endDate.getTime());
    }

    public LiveData<List<TransactionEntity>> getTransactionsFromDate(Date startDate) {
        return transactionDao.getTransactionsFromDate(startDate.getTime());
    }

    public LiveData<List<TransactionEntity>> getTransactionsToDate(Date endDate) {
        return transactionDao.getTransactionsToDate(endDate.getTime());
    }

    // Пагинация
    public LiveData<List<TransactionEntity>> getRecentTransactions(int limit) {
        return transactionDao.getRecentTransactions(limit);
    }

    public LiveData<List<TransactionEntity>> getRecentTransactionsForGoal(String goalId, int limit) {
        return transactionDao.getRecentTransactionsForGoal(goalId, limit);
    }

    // Поиск
    public LiveData<List<TransactionEntity>> searchTransactions(String query) {
        return transactionDao.searchTransactions(query);
    }

    // Статистика
    public LiveData<Integer> getTransactionCount() {
        return transactionDao.getTransactionCount();
    }

    public LiveData<Integer> getTransactionCountForGoal(String goalId) {
        return transactionDao.getTransactionCountForGoal(goalId);
    }

    public LiveData<Double> getTotalDepositsForGoal(String goalId) {
        return transactionDao.getTotalDepositsForGoal(goalId);
    }

    public LiveData<Double> getTotalWithdrawalsForGoal(String goalId) {
        return transactionDao.getTotalWithdrawalsForGoal(goalId);
    }

    public LiveData<Double> getNetAmountForGoal(String goalId) {
        return transactionDao.getNetAmountForGoal(goalId);
    }

    public LiveData<Double> getTotalDepositsBetween(Date startDate, Date endDate) {
        return transactionDao.getTotalDepositsBetween(startDate.getTime(), endDate.getTime());
    }

    public LiveData<Double> getTotalWithdrawalsBetween(Date startDate, Date endDate) {
        return transactionDao.getTotalWithdrawalsBetween(startDate.getTime(), endDate.getTime());
    }

    // Аналитика
    public LiveData<List<TransactionDao.MonthSummary>> getMonthlySummary() {
        return transactionDao.getMonthlySummary();
    }

    public LiveData<List<TransactionDao.CategorySummary>> getCategorySummary() {
        return transactionDao.getCategorySummary();
    }

    // Пакетные операции
    public void deleteTransactionsByGoalId(String goalId) {
        executor.execute(() -> {
            transactionDao.deleteByGoalId(goalId);
        });
    }

    public void deleteTransactionsByDepositId(String depositId) {
        executor.execute(() -> {
            transactionDao.deleteByDepositId(depositId);
        });
    }
}