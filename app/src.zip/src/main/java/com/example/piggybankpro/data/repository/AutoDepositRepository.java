package com.example.piggybankpro.data.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.piggybankpro.data.local.database.AppDatabase;
import com.example.piggybankpro.data.local.database.DatabaseClient;
import com.example.piggybankpro.data.local.dao.AutoDepositDao;
import com.example.piggybankpro.data.local.dao.GoalDao;
import com.example.piggybankpro.data.local.dao.GoalDepositCrossRefDao;
import com.example.piggybankpro.data.local.dao.TransactionDao;
import com.example.piggybankpro.data.local.entities.AutoDepositEntity;
import com.example.piggybankpro.data.local.entities.GoalDepositCrossRefEntity;
import com.example.piggybankpro.data.local.entities.TransactionEntity;

import java.util.Date;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class AutoDepositRepository {

    private AutoDepositDao autoDepositDao;
    private GoalDao goalDao;
    private GoalDepositCrossRefDao crossRefDao;
    private TransactionDao transactionDao;
    private Executor executor;

    public AutoDepositRepository(Application application) {
        AppDatabase database = DatabaseClient.getInstance(application).getAppDatabase();
        autoDepositDao = database.autoDepositDao();
        goalDao = database.goalDao();
        crossRefDao = database.goalDepositCrossRefDao();
        transactionDao = database.transactionDao();
        executor = Executors.newSingleThreadExecutor();
    }

    // Основные операции
    public LiveData<List<AutoDepositEntity>> getAllAutoDeposits() {
        return autoDepositDao.getAllAutoDeposits();
    }

    public LiveData<AutoDepositEntity> getAutoDepositById(String depositId) {
        return autoDepositDao.getAutoDepositById(depositId);
    }

    public LiveData<List<AutoDepositEntity>> getActiveAutoDeposits() {
        return autoDepositDao.getActiveAutoDeposits();
    }

    public void insert(AutoDepositEntity autoDeposit, List<GoalDepositCrossRefEntity> crossRefs) {
        executor.execute(() -> {
            // Сохраняем автопополнение
            autoDepositDao.insert(autoDeposit);

            // Сохраняем связи с целями
            if (crossRefs != null && !crossRefs.isEmpty()) {
                for (GoalDepositCrossRefEntity crossRef : crossRefs) {
                    crossRef.setAutoDepositId(autoDeposit.getId());
                    crossRefDao.insert(crossRef);
                }
            }
        });
    }

    public void update(AutoDepositEntity autoDeposit, List<GoalDepositCrossRefEntity> crossRefs) {
        executor.execute(() -> {
            // Обновляем автопополнение
            autoDepositDao.update(autoDeposit);

            // Удаляем старые связи
            crossRefDao.deleteByDepositId(autoDeposit.getId());

            // Добавляем новые связи
            if (crossRefs != null && !crossRefs.isEmpty()) {
                for (GoalDepositCrossRefEntity crossRef : crossRefs) {
                    crossRef.setAutoDepositId(autoDeposit.getId());
                    crossRefDao.insert(crossRef);
                }
            }
        });
    }

    public void delete(AutoDepositEntity autoDeposit) {
        executor.execute(() -> {
            // Удаляем связи с целями
            crossRefDao.deleteByDepositId(autoDeposit.getId());

            // Удаляем автопополнение
            autoDepositDao.delete(autoDeposit);
        });
    }

    // Работа со связями целей
    public LiveData<List<GoalDepositCrossRefEntity>> getCrossRefsByDepositId(String depositId) {
        return crossRefDao.getCrossRefsByDepositId(depositId);
    }

    public LiveData<List<GoalDepositCrossRefEntity>> getCrossRefsByGoalId(String goalId) {
        return crossRefDao.getCrossRefsByGoalId(goalId);
    }

    public void addGoalToDeposit(String depositId, String goalId, Double amount, Double percentage, Integer distributionType) {
        executor.execute(() -> {
            GoalDepositCrossRefEntity crossRef = new GoalDepositCrossRefEntity(goalId, depositId);
            crossRef.setAmount(amount);
            crossRef.setPercentage(percentage);
            crossRef.setDistributionType(distributionType);
            crossRefDao.insert(crossRef);
        });
    }

    public void removeGoalFromDeposit(String depositId, String goalId) {
        executor.execute(() -> {
            crossRefDao.delete(depositId, goalId);
        });
    }

    // Выполнение автопополнения
    public void executeAutoDeposit(String depositId) {
        executor.execute(() -> {
            AutoDepositEntity deposit = autoDepositDao.getAutoDepositById(depositId).getValue();
            if (deposit != null && deposit.getIsActive()) {
                List<GoalDepositCrossRefEntity> crossRefs = crossRefDao.getCrossRefsByDepositId(depositId).getValue();

                if (crossRefs != null && !crossRefs.isEmpty()) {
                    double totalAmount = deposit.getAmount();

                    for (GoalDepositCrossRefEntity crossRef : crossRefs) {
                        // Рассчитываем сумму для каждой цели
                        double amountForGoal = 0;

                        if (crossRef.getDistributionType() == 1) {
                            // Фиксированная сумма
                            amountForGoal = crossRef.getAmount() != null ? crossRef.getAmount() : 0;
                        } else if (crossRef.getDistributionType() == 2) {
                            // Процент от общей суммы
                            if (crossRef.getPercentage() != null) {
                                amountForGoal = (crossRef.getPercentage() / 100.0) * totalAmount;
                            }
                        }

                        if (amountForGoal > 0) {
                            // Пополняем цель
                            goalDao.updateCurrentAmount(crossRef.getGoalId(), amountForGoal);

                            // Создаем транзакцию
                            TransactionEntity transaction = new TransactionEntity(
                                    crossRef.getGoalId(),
                                    depositId,
                                    amountForGoal
                            );
                            transaction.setDescription("Автопополнение: " + deposit.getName());
                            transactionDao.insert(transaction);
                        }
                    }

                    // Обновляем даты выполнения
                    deposit.execute();
                    autoDepositDao.update(deposit);
                }
            }
        });
    }

    // Проверка и выполнение всех просроченных автопополнений
    public void executeDueAutoDeposits() {
        executor.execute(() -> {
            long currentTime = System.currentTimeMillis();
            List<AutoDepositEntity> dueDeposits = autoDepositDao.getDueAutoDeposits(currentTime);

            for (AutoDepositEntity deposit : dueDeposits) {
                executeAutoDeposit(deposit.getId());
            }
        });
    }

    // Управление статусом
    public void setActive(String depositId, boolean isActive) {
        executor.execute(() -> {
            autoDepositDao.setActive(depositId, isActive);
        });
    }

    // Статистика
    public LiveData<Integer> getActiveDepositsCount() {
        return autoDepositDao.getActiveDepositsCount();
    }

    public LiveData<Double> getTotalMonthlyDeposit() {
        return autoDepositDao.getTotalMonthlyDeposit();
    }
}