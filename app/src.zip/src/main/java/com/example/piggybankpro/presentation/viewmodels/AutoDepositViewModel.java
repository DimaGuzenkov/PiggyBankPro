package com.example.piggybankpro.presentation.viewmodels;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.piggybankpro.data.local.entities.AutoDepositEntity;
import com.example.piggybankpro.data.local.entities.GoalDepositCrossRefEntity;
import com.example.piggybankpro.data.repository.AutoDepositRepository;
import com.example.piggybankpro.data.repository.RepositoryFactory;

import java.util.List;

public class AutoDepositViewModel extends AndroidViewModel {

    private AutoDepositRepository autoDepositRepository;
    private LiveData<List<AutoDepositEntity>> allAutoDeposits;
    private MutableLiveData<AutoDepositEntity> selectedAutoDeposit = new MutableLiveData<>();
    private MutableLiveData<Boolean> isLoading = new MutableLiveData<>(false);
    private MutableLiveData<String> errorMessage = new MutableLiveData<>();

    public AutoDepositViewModel(@NonNull Application application) {
        super(application);
        autoDepositRepository = RepositoryFactory.getInstance(application).getAutoDepositRepository();
        allAutoDeposits = autoDepositRepository.getAllAutoDeposits();
    }

    // Получение данных
    public LiveData<List<AutoDepositEntity>> getAllAutoDeposits() {
        return allAutoDeposits;
    }

    public LiveData<AutoDepositEntity> getAutoDepositById(String depositId) {
        return autoDepositRepository.getAutoDepositById(depositId);
    }

    public LiveData<List<AutoDepositEntity>> getActiveAutoDeposits() {
        return autoDepositRepository.getActiveAutoDeposits();
    }

    // CRUD операции
    public void createAutoDeposit(AutoDepositEntity autoDeposit, List<GoalDepositCrossRefEntity> crossRefs) {
        try {
            validateAutoDeposit(autoDeposit);
            autoDepositRepository.insert(autoDeposit, crossRefs);
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при создании автопополнения: " + e.getMessage());
        }
    }

    public void updateAutoDeposit(AutoDepositEntity autoDeposit, List<GoalDepositCrossRefEntity> crossRefs) {
        try {
            validateAutoDeposit(autoDeposit);
            autoDepositRepository.update(autoDeposit, crossRefs);
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при обновлении автопополнения: " + e.getMessage());
        }
    }

    public void deleteAutoDeposit(AutoDepositEntity autoDeposit) {
        try {
            autoDepositRepository.delete(autoDeposit);
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при удалении автопополнения: " + e.getMessage());
        }
    }

    // Валидация
    private void validateAutoDeposit(AutoDepositEntity autoDeposit) throws Exception {
        if (autoDeposit.getName() == null || autoDeposit.getName().trim().isEmpty()) {
            throw new Exception("Введите название автопополнения");
        }

        if (autoDeposit.getAmount() == null || autoDeposit.getAmount() <= 0) {
            throw new Exception("Сумма должна быть больше нуля");
        }

        if (autoDeposit.getDepositType() == AutoDepositEntity.TYPE_PERCENTAGE) {
            if (autoDeposit.getPercentage() == null || autoDeposit.getPercentage() <= 0) {
                throw new Exception("Процент должен быть больше нуля");
            }
            if (autoDeposit.getPercentage() > 100) {
                throw new Exception("Процент не может превышать 100%");
            }
        }
    }

    // Управление связями с целями
    public LiveData<List<GoalDepositCrossRefEntity>> getCrossRefsByDepositId(String depositId) {
        return autoDepositRepository.getCrossRefsByDepositId(depositId);
    }

    public LiveData<List<GoalDepositCrossRefEntity>> getCrossRefsByGoalId(String goalId) {
        return autoDepositRepository.getCrossRefsByGoalId(goalId);
    }

    public void addGoalToDeposit(String depositId, String goalId, Double amount, Double percentage, Integer distributionType) {
        try {
            if (distributionType == 1 && (amount == null || amount <= 0)) {
                errorMessage.setValue("Введите сумму для фиксированного распределения");
                return;
            }
            if (distributionType == 2 && (percentage == null || percentage <= 0 || percentage > 100)) {
                errorMessage.setValue("Процент должен быть от 1 до 100");
                return;
            }

            autoDepositRepository.addGoalToDeposit(depositId, goalId, amount, percentage, distributionType);
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при добавлении цели: " + e.getMessage());
        }
    }

    public void removeGoalFromDeposit(String depositId, String goalId) {
        try {
            autoDepositRepository.removeGoalFromDeposit(depositId, goalId);
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при удалении цели: " + e.getMessage());
        }
    }

    // Выполнение автопополнения
    public void executeAutoDeposit(String depositId) {
        try {
            autoDepositRepository.executeAutoDeposit(depositId);
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при выполнении автопополнения: " + e.getMessage());
        }
    }

    public void executeDueAutoDeposits() {
        try {
            autoDepositRepository.executeDueAutoDeposits();
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при выполнении отложенных автопополнений: " + e.getMessage());
        }
    }

    // Управление статусом
    public void toggleAutoDepositStatus(String depositId, boolean isActive) {
        try {
            autoDepositRepository.setActive(depositId, isActive);
            errorMessage.setValue(null);
        } catch (Exception e) {
            errorMessage.setValue("Ошибка при изменении статуса: " + e.getMessage());
        }
    }

    // Статистика
    public LiveData<Integer> getActiveDepositsCount() {
        return autoDepositRepository.getActiveDepositsCount();
    }

    public LiveData<Double> getTotalMonthlyDeposit() {
        return autoDepositRepository.getTotalMonthlyDeposit();
    }

    // Получение и установка выбранного автопополнения
    public LiveData<AutoDepositEntity> getSelectedAutoDeposit() {
        return selectedAutoDeposit;
    }

    public void setSelectedAutoDeposit(AutoDepositEntity autoDeposit) {
        selectedAutoDeposit.setValue(autoDeposit);
    }

    public void clearSelectedAutoDeposit() {
        selectedAutoDeposit.setValue(null);
    }

    // Состояние загрузки
    public LiveData<Boolean> getIsLoading() {
        return isLoading;
    }

    public void setLoading(boolean loading) {
        isLoading.setValue(loading);
    }

    // Ошибки
    public LiveData<String> getErrorMessage() {
        return errorMessage;
    }

    public void clearError() {
        errorMessage.setValue(null);
    }

    // Вспомогательные методы
    public String getPeriodTypeString(int periodType) {
        switch (periodType) {
            case AutoDepositEntity.PERIOD_DAILY: return "Ежедневно";
            case AutoDepositEntity.PERIOD_WEEKLY: return "Еженедельно";
            case AutoDepositEntity.PERIOD_BIWEEKLY: return "Раз в две недели";
            case AutoDepositEntity.PERIOD_MONTHLY: return "Ежемесячно";
            case AutoDepositEntity.PERIOD_QUARTERLY: return "Ежеквартально";
            case AutoDepositEntity.PERIOD_YEARLY: return "Ежегодно";
            default: return "Не указано";
        }
    }

    public String getDepositTypeString(int depositType) {
        return depositType == AutoDepositEntity.TYPE_FIXED ? "Фиксированная сумма" : "Процент";
    }
}