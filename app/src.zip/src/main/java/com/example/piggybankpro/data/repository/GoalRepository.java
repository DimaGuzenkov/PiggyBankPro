package com.example.piggybankpro.data.repository;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import com.example.piggybankpro.data.local.database.AppDatabase;
import com.example.piggybankpro.data.local.database.DatabaseClient;
import com.example.piggybankpro.data.local.dao.GoalDao;
import com.example.piggybankpro.data.local.dao.TransactionDao;
import com.example.piggybankpro.data.local.entities.GoalEntity;
import com.example.piggybankpro.data.local.entities.TransactionEntity;

import java.util.Date;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class GoalRepository {

    private GoalDao goalDao;
    private TransactionDao transactionDao;
    private LiveData<List<GoalEntity>> allGoals;
    private Executor executor;

    public GoalRepository(Application application) {
        AppDatabase database = DatabaseClient.getInstance(application).getAppDatabase();
        goalDao = database.goalDao();
        transactionDao = database.transactionDao();
        allGoals = goalDao.getAllGoals();
        executor = Executors.newSingleThreadExecutor();
    }

    // Основные операции
    public LiveData<List<GoalEntity>> getAllGoals() {
        return allGoals;
    }

    public LiveData<GoalEntity> getGoalById(String goalId) {
        return goalDao.getGoalById(goalId);
    }

    public void insert(GoalEntity goal) {
        executor.execute(() -> {
            goalDao.insert(goal);
            // Создаем транзакцию для начальной суммы, если она не нулевая
            if (goal.getCurrentAmount() != null && goal.getCurrentAmount() > 0) {
                TransactionEntity transaction = new TransactionEntity(
                        goal.getId(),
                        goal.getCurrentAmount(),
                        TransactionEntity.TYPE_DEPOSIT
                );
                transaction.setDescription("Начальная сумма");
                transactionDao.insert(transaction);
            }
        });
    }

    public void update(GoalEntity goal) {
        executor.execute(() -> {
            goalDao.update(goal);
        });
    }

    public void delete(GoalEntity goal) {
        executor.execute(() -> {
            goalDao.delete(goal);
        });
    }

    public void deleteById(String goalId) {
        executor.execute(() -> {
            goalDao.deleteById(goalId);
        });
    }

    // Операции с суммами
    public void deposit(String goalId, Double amount, String description) {
        executor.execute(() -> {
            // Обновляем сумму в цели
            goalDao.updateCurrentAmount(goalId, amount);

            // Создаем запись о транзакции
            TransactionEntity transaction = new TransactionEntity(
                    goalId,
                    amount,
                    TransactionEntity.TYPE_DEPOSIT
            );
            transaction.setDescription(description != null ? description : "Пополнение");
            transactionDao.insert(transaction);
        });
    }

    public void withdraw(String goalId, Double amount, String description) {
        executor.execute(() -> {
            // Проверяем, достаточно ли средств
            GoalEntity goal = goalDao.getGoalById(goalId).getValue();
            if (goal != null && goal.getCurrentAmount() >= amount) {
                // Обновляем сумму в цели (уменьшаем)
                goalDao.updateCurrentAmount(goalId, -amount);

                // Создаем запись о транзакции
                TransactionEntity transaction = new TransactionEntity(
                        goalId,
                        amount,
                        TransactionEntity.TYPE_WITHDRAWAL
                );
                transaction.setDescription(description != null ? description : "Списание");
                transactionDao.insert(transaction);
            }
        });
    }

    public void transfer(String fromGoalId, String toGoalId, Double amount, String description) {
        executor.execute(() -> {
            GoalEntity fromGoal = goalDao.getGoalById(fromGoalId).getValue();
            if (fromGoal != null && fromGoal.getCurrentAmount() >= amount) {
                // Снимаем с одной цели
                goalDao.updateCurrentAmount(fromGoalId, -amount);

                // Добавляем к другой цели
                goalDao.updateCurrentAmount(toGoalId, amount);

                // Создаем запись о транзакции перевода
                TransactionEntity transaction = new TransactionEntity(
                        fromGoalId,
                        amount,
                        TransactionEntity.TYPE_TRANSFER
                );
                transaction.setRelatedGoalId(toGoalId);
                transaction.setDescription(description != null ? description : "Перевод между целями");
                transactionDao.insert(transaction);
            }
        });
    }

    // Получение специальных списков
    public LiveData<List<GoalEntity>> getRootGoals() {
        return goalDao.getRootGoals();
    }

    public LiveData<List<GoalEntity>> getSubGoals(String parentId) {
        return goalDao.getSubGoals(parentId);
    }

    public LiveData<List<GoalEntity>> getDirectoryGoals() {
        return goalDao.getDirectoryGoals();
    }

    public LiveData<List<GoalEntity>> getCompletedGoals() {
        return goalDao.getCompletedGoals();
    }

    public LiveData<List<GoalEntity>> getActiveGoals() {
        return goalDao.getActiveGoals();
    }

    public LiveData<List<GoalEntity>> getArchivedGoals() {
        return goalDao.getArchivedGoals();
    }

    // Поиск
    public LiveData<List<GoalEntity>> searchGoals(String query) {
        return goalDao.searchGoals(query);
    }

    // Статистика
    public LiveData<Integer> getGoalsCount() {
        return goalDao.getGoalsCount();
    }

    public LiveData<Integer> getCompletedGoalsCount() {
        return goalDao.getCompletedGoalsCount();
    }

    public LiveData<Double> getTotalSavedAmount() {
        return goalDao.getTotalSavedAmount();
    }

    public LiveData<Double> getTotalTargetAmount() {
        return goalDao.getTotalTargetAmount();
    }

    // Работа с директориями
    public void moveGoalToDirectory(String goalId, String directoryId) {
        executor.execute(() -> {
            goalDao.updateParent(goalId, directoryId);
        });
    }

    public void removeFromDirectory(String goalId) {
        executor.execute(() -> {
            goalDao.updateParent(goalId, null);
        });
    }

    // Изменение статусов
    public void archiveGoal(String goalId, boolean archive) {
        executor.execute(() -> {
            goalDao.setArchived(goalId, archive);
        });
    }

    public void completeGoal(String goalId, boolean complete) {
        executor.execute(() -> {
            goalDao.setCompleted(goalId, complete);
        });
    }

    // Иерархические операции
    public void calculateDirectoryTotal(String directoryId) {
        executor.execute(() -> {
            List<GoalEntity> subGoals = goalDao.getSubGoals(directoryId).getValue();
            if (subGoals != null) {
                double total = 0;
                for (GoalEntity goal : subGoals) {
                    total += goal.getCurrentAmount();
                }

                // Обновляем сумму директории
                GoalEntity directory = goalDao.getGoalById(directoryId).getValue();
                if (directory != null) {
                    directory.setCurrentAmount(total);
                    goalDao.update(directory);
                }
            }
        });
    }
}