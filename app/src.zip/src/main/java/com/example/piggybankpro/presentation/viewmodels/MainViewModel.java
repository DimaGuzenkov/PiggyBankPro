package com.example.piggybankpro.presentation.viewmodels;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.piggybankpro.data.local.entities.GoalEntity;
import com.example.piggybankpro.data.repository.GoalRepository;
import com.example.piggybankpro.data.repository.RepositoryFactory;

import java.util.List;

public class MainViewModel extends AndroidViewModel {

    private GoalRepository goalRepository;
    private LiveData<List<GoalEntity>> allGoals;
    private LiveData<Integer> goalsCount;
    private LiveData<Integer> completedGoalsCount;
    private LiveData<Double> totalSavedAmount;
    private LiveData<Double> totalTargetAmount;

    private MutableLiveData<String> searchQuery = new MutableLiveData<>("");
    private MutableLiveData<Integer> filterType = new MutableLiveData<>(0); // 0 - все, 1 - активные, 2 - завершенные, 3 - директории
    private MutableLiveData<String> sortBy = new MutableLiveData<>("priority"); // priority, date, amount

    public MainViewModel(@NonNull Application application) {
        super(application);
        goalRepository = RepositoryFactory.getInstance(application).getGoalRepository();
        allGoals = goalRepository.getAllGoals();
        goalsCount = goalRepository.getGoalsCount();
        completedGoalsCount = goalRepository.getCompletedGoalsCount();
        totalSavedAmount = goalRepository.getTotalSavedAmount();
        totalTargetAmount = goalRepository.getTotalTargetAmount();
    }

    // Получение данных
    public LiveData<List<GoalEntity>> getAllGoals() {
        return allGoals;
    }

    public LiveData<Integer> getGoalsCount() {
        return goalsCount;
    }

    public LiveData<Integer> getCompletedGoalsCount() {
        return completedGoalsCount;
    }

    public LiveData<Double> getTotalSavedAmount() {
        return totalSavedAmount;
    }

    public LiveData<Double> getTotalTargetAmount() {
        return totalTargetAmount;
    }

    // Поиск и фильтрация
    public LiveData<String> getSearchQuery() {
        return searchQuery;
    }

    public void setSearchQuery(String query) {
        searchQuery.setValue(query);
    }

    public LiveData<Integer> getFilterType() {
        return filterType;
    }

    public void setFilterType(int type) {
        filterType.setValue(type);
    }

    public LiveData<String> getSortBy() {
        return sortBy;
    }

    public void setSortBy(String sort) {
        sortBy.setValue(sort);
    }

    // Статистика
    public LiveData<Double> calculateOverallProgress() {
        MutableLiveData<Double> progress = new MutableLiveData<>(0.0);

        totalSavedAmount.observeForever(saved -> {
            totalTargetAmount.observeForever(target -> {
                if (target != null && target > 0) {
                    double percentage = (saved != null ? saved : 0.0) / target * 100;
                    progress.setValue(percentage);
                } else {
                    progress.setValue(0.0);
                }
            });
        });

        return progress;
    }

    // Вспомогательные методы
    public String formatCurrency(double amount) {
        return String.format("%.2f ₽", amount);
    }

    public String formatPercentage(double percentage) {
        return String.format("%.1f%%", percentage);
    }
}