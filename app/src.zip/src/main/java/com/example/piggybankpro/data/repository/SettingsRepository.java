package com.example.piggybankpro.data.repository;

import android.app.Application;
import android.content.SharedPreferences;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.piggybankpro.data.local.database.AppDatabase;
import com.example.piggybankpro.data.local.database.DatabaseClient;
import com.example.piggybankpro.data.local.dao.SettingsDao;
import com.example.piggybankpro.data.local.entities.SettingsEntity;

import java.util.Date;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class SettingsRepository {

    private static final String PREFS_NAME = "piggybankpro_prefs";
    private static final String PREF_FIRST_RUN = "first_run";

    private SettingsDao settingsDao;
    private SharedPreferences sharedPreferences;
    private MutableLiveData<SettingsEntity> settingsLiveData;
    private Executor executor;

    public SettingsRepository(Application application) {
        AppDatabase database = DatabaseClient.getInstance(application).getAppDatabase();
        settingsDao = database.settingsDao();
        sharedPreferences = application.getSharedPreferences(PREFS_NAME, Application.MODE_PRIVATE);
        settingsLiveData = new MutableLiveData<>();
        executor = Executors.newSingleThreadExecutor();

        // Инициализация настроек при первом запуске
        initializeSettings();
    }

    private void initializeSettings() {
        executor.execute(() -> {
            if (isFirstRun()) {
                // Создаем настройки по умолчанию
                SettingsEntity defaultSettings = new SettingsEntity();
                settingsDao.insert(defaultSettings);

                // Помечаем, что приложение уже запускалось
                setFirstRunCompleted();
            }

            // Загружаем настройки
            SettingsEntity settings = settingsDao.getSettingsSync();
            settingsLiveData.postValue(settings);
        });
    }

    private boolean isFirstRun() {
        return sharedPreferences.getBoolean(PREF_FIRST_RUN, true);
    }

    private void setFirstRunCompleted() {
        sharedPreferences.edit().putBoolean(PREF_FIRST_RUN, false).apply();
    }

    public LiveData<SettingsEntity> getSettings() {
        return settingsDao.getSettings();
    }

    public void updateSettings(SettingsEntity settings) {
        executor.execute(() -> {
            settingsDao.update(settings);
        });
    }

    // Обновление отдельных настроек
    public void updateNotificationsEnabled(boolean enabled) {
        executor.execute(() -> {
            settingsDao.updateNotificationsEnabled(enabled);
        });
    }

    public void updateNotificationSoundEnabled(boolean enabled) {
        executor.execute(() -> {
            settingsDao.updateNotificationSoundEnabled(enabled);
        });
    }

    public void updateVibrationEnabled(boolean enabled) {
        executor.execute(() -> {
            settingsDao.updateVibrationEnabled(enabled);
        });
    }

    public void updateThemeMode(int themeMode) {
        executor.execute(() -> {
            settingsDao.updateThemeMode(themeMode);
        });
    }

    public void updateTextSize(int textSize) {
        executor.execute(() -> {
            settingsDao.updateTextSize(textSize);
        });
    }

    public void updateCurrency(String currency) {
        executor.execute(() -> {
            settingsDao.updateCurrency(currency);
        });
    }

    public void updateBiometricAuthEnabled(boolean enabled) {
        executor.execute(() -> {
            settingsDao.updateBiometricAuthEnabled(enabled);
        });
    }

    public void updateAutoBackupEnabled(boolean enabled) {
        executor.execute(() -> {
            settingsDao.updateAutoBackupEnabled(enabled);
        });
    }

    public void updateBackupFrequency(int frequency) {
        executor.execute(() -> {
            settingsDao.updateBackupFrequency(frequency);
        });
    }

    public void updateLastBackupDate(Date backupDate) {
        executor.execute(() -> {
            settingsDao.updateLastBackupDate(backupDate.getTime());
        });
    }

    // Вспомогательные методы для SharedPreferences
    public void saveString(String key, String value) {
        sharedPreferences.edit().putString(key, value).apply();
    }

    public String getString(String key, String defaultValue) {
        return sharedPreferences.getString(key, defaultValue);
    }

    public void saveBoolean(String key, boolean value) {
        sharedPreferences.edit().putBoolean(key, value).apply();
    }

    public boolean getBoolean(String key, boolean defaultValue) {
        return sharedPreferences.getBoolean(key, defaultValue);
    }

    public void saveInt(String key, int value) {
        sharedPreferences.edit().putInt(key, value).apply();
    }

    public int getInt(String key, int defaultValue) {
        return sharedPreferences.getInt(key, defaultValue);
    }
}