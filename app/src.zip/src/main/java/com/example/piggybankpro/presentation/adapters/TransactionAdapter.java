package com.example.piggybankpro.presentation.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.piggybankpro.R;
import com.example.piggybankpro.data.local.entities.TransactionEntity;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.TransactionViewHolder> {

    private List<TransactionEntity> transactions;
//    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault());

    public TransactionAdapter(List<TransactionEntity> transactions) {
        this.transactions = transactions;
    }

    public void updateTransactions(List<TransactionEntity> newTransactions) {
        this.transactions = newTransactions;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public TransactionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_transaction, parent, false);
        return new TransactionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TransactionViewHolder holder, int position) {
        TransactionEntity transaction = transactions.get(position);
        holder.bind(transaction);
    }

    @Override
    public int getItemCount() {
        return transactions != null ? transactions.size() : 0;
    }

    static class TransactionViewHolder extends RecyclerView.ViewHolder {

        TextView textViewAmount;
        TextView textViewDescription;
        TextView textViewDate;
        TextView textViewType;
        View typeIndicator;
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault());

        public TransactionViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewAmount = itemView.findViewById(R.id.text_view_amount);
            textViewDescription = itemView.findViewById(R.id.text_view_description);
            textViewDate = itemView.findViewById(R.id.text_view_date);
            textViewType = itemView.findViewById(R.id.text_view_type);
            typeIndicator = itemView.findViewById(R.id.view_type_indicator);
        }

        public void bind(TransactionEntity transaction) {
            // Сумма
            String amountText = String.format(Locale.getDefault(), "%.2f ₽", transaction.getAmount());
            textViewAmount.setText(amountText);

            // Описание
            textViewDescription.setText(transaction.getDescription() != null ?
                    transaction.getDescription() : "Нет описания");

            // Дата
            if (transaction.getTransactionDate() != null) {
                textViewDate.setText(dateFormat.format(transaction.getTransactionDate()));
            } else {
                textViewDate.setText("Дата не указана");
            }

            // Тип транзакции
            String typeText = "";
            int color = 0xFF4CAF50; // Зеленый по умолчанию

            switch (transaction.getTransactionType()) {
                case TransactionEntity.TYPE_DEPOSIT:
                    typeText = "Пополнение";
                    color = 0xFF4CAF50; // Зеленый
                    break;
                case TransactionEntity.TYPE_WITHDRAWAL:
                    typeText = "Списание";
                    color = 0xFFF44336; // Красный
                    break;
                case TransactionEntity.TYPE_TRANSFER:
                    typeText = "Перевод";
                    color = 0xFF2196F3; // Синий
                    break;
                case TransactionEntity.TYPE_ADJUSTMENT:
                    typeText = "Корректировка";
                    color = 0xFFFF9800; // Оранжевый
                    break;
            }

            textViewType.setText(typeText);
            typeIndicator.setBackgroundColor(color);

            // Для списаний добавляем минус
            if (transaction.getTransactionType() == TransactionEntity.TYPE_WITHDRAWAL) {
                textViewAmount.setText("-" + amountText);
            }
        }
    }
}